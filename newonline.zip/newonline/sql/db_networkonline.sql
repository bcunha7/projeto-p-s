-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Tempo de geração: 25/01/2024 às 21:23
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `db_networkonline`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_chamados`
--

CREATE TABLE `tb_chamados` (
  `cha_codigo` int(11) NOT NULL,
  `cha_assunto` varchar(255) NOT NULL,
  `cha_contato` varchar(255) NOT NULL,
  `cha_telefone` varchar(255) NOT NULL,
  `cha_email` varchar(255) NOT NULL,
  `cha_dataabertura` datetime NOT NULL,
  `cha_dataagendamento` datetime DEFAULT NULL,
  `pes_codigo` int(11) NOT NULL,
  `usu_codigo` int(11) NOT NULL,
  `cha_status` int(11) NOT NULL,
  `cha_agendado` tinyint(1) DEFAULT NULL,
  `cha_obsagendamento` varchar(2000) DEFAULT NULL,
  `cha_detalhes` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_chamados`
--

INSERT INTO `tb_chamados` (`cha_codigo`, `cha_assunto`, `cha_contato`, `cha_telefone`, `cha_email`, `cha_dataabertura`, `cha_dataagendamento`, `pes_codigo`, `usu_codigo`, `cha_status`, `cha_agendado`, `cha_obsagendamento`, `cha_detalhes`) VALUES
(4, 'Problemas com acesso ao sistema', 'João Silva', '11988887777', 'joao.silva@email.com', '2024-01-15 09:30:45', '2024-02-10 10:00:00', 1, 1, 1, 0, '', 'Usuário relatou dificuldades para acessar a plataforma.'),
(5, 'Erro ao salvar alterações', 'Maria Oliveira', '11999998888', 'maria.oliveira@email.com', '2024-01-16 14:22:30', '2024-02-15 15:30:00', 2, 2, 2, 1, 'Chamado agendado para corrigir o problema', 'Ao tentar salvar, o sistema apresentou uma mensagem de erro.'),
(6, 'Dúvidas sobre funcionalidades', 'Pedro Santos', '11977776666', 'pedro.santos@email.com', '2024-01-18 11:10:20', '2024-02-20 09:00:00', 5, 2, 0, 0, '', 'Cliente necessita de esclarecimentos sobre algumas funcionalidades.'),
(7, 'Teste de Performance', 'Luciana Lima', '11966665555', 'luciana.lima@email.com', '2024-01-20 16:45:18', '2024-02-25 14:00:00', 8, 5, 1, 1, 'Agendado para avaliar a performance da aplicação', 'Cliente relata lentidão em determinadas operações.'),
(8, 'Problema na exibição de relatórios', 'Eduardo Costa', '11944443333', 'eduardo.costa@email.com', '2024-01-22 09:05:35', '2024-02-28 11:30:00', 1, 8, 2, 0, '', 'Relatórios não estão sendo exibidos corretamente.'),
(9, 'Erro na exportação de dados', 'Camila Pereira', '11933332222', 'camila.pereira@email.com', '2024-01-23 13:20:40', '2024-03-01 16:00:00', 4, 1, 0, 1, 'Chamado agendado para corrigir o problema', 'Exportação de dados para CSV está gerando arquivo corrompido.'),
(10, 'Melhorias na interface do usuário', 'Fernando Almeida', '11922221111', 'fernando.almeida@email.com', '2024-01-25 08:30:15', '2024-03-05 09:30:00', 2, 4, 1, 0, '', 'Cliente sugere ajustes para melhorar a usabilidade.'),
(11, 'Problema no processo de login', 'Amanda Silva', '11911110000', 'amanda.silva@email.com', '2024-01-27 17:15:55', '2024-03-10 14:45:00', 3, 7, 2, 1, 'Agendado para verificar falha no login', 'Usuário enfrenta dificuldades ao tentar realizar o login.'),
(12, 'Teste de Segurança', 'Ricardo Martins', '11888887777', 'ricardo.martins@email.com', '2024-01-30 10:40:25', '2024-03-15 12:00:00', 3, 4, 0, 0, '', 'Necessário avaliar a segurança da aplicação contra possíveis vulnerabilidades.'),
(13, 'Solicitação de Novo Recurso', 'Isabela Oliveira', '11877776666', 'isabela.oliveira@email.com', '2024-02-01 14:55:30', '2024-03-20 11:15:00', 6, 4, 1, 1, 'Agendado para discutir a implementação do recurso', 'Cliente deseja a adição de uma nova funcionalidade.');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_chamados_interacao`
--

CREATE TABLE `tb_chamados_interacao` (
  `chi_codigo` int(11) NOT NULL,
  `cha_codigo` int(11) NOT NULL,
  `chi_comentario` varchar(2000) NOT NULL,
  `chi_autor` varchar(120) NOT NULL,
  `chi_data` datetime NOT NULL,
  `chi_interacaointerna` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_cliente`
--

CREATE TABLE `tb_cliente` (
  `pes_codigo` int(11) NOT NULL,
  `pes_fantasia` varchar(255) NOT NULL,
  `pes_razao` varchar(255) NOT NULL,
  `pes_cpfcnpj` varchar(30) NOT NULL,
  `pes_datacadastro` date NOT NULL,
  `pes_tipopessoa` varchar(250) NOT NULL,
  `pes_observacao` varchar(500) DEFAULT NULL,
  `pes_ativo` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_cliente`
--

INSERT INTO `tb_cliente` (`pes_codigo`, `pes_fantasia`, `pes_razao`, `pes_cpfcnpj`, `pes_datacadastro`, `pes_tipopessoa`, `pes_observacao`, `pes_ativo`) VALUES
(1, 'ClienteNovo', 'Novo Comércio S.A.', '88.888.888/0001-88', '2024-01-27', 'Pessoa jurídica', 'Observação Novo', 's'),
(2, 'ClienteXYZ3', 'XYZ Comércio 3 Ltda', '99.999.999/0001-99', '2024-01-28', 'Pessoa jurídica', 'Observação XYZ 3', 's'),
(3, 'Cliente1234', '1234 Indústria e Comércio', '101.010.101/0001-10', '2024-01-28', 'Pessoa jurídica', 'Observação 1234', 's'),
(4, 'ClienteABC2', 'ABC Consultoria 2 S.A.', '121.212.121/0001-12', '2024-01-29', 'Pessoa jurídica', 'Observação ABC 2', 's'),
(5, 'ClienteTeste2', 'Teste Comércio e Serviços', '131.313.131/0001-13', '2024-01-30', 'Pessoa jurídica', 'Observação Teste 2', 's'),
(6, 'ClienteTeste3', 'Teste Comércio e Serviços 3', '181.818.181/0001-18', '2024-02-02', 'Pessoa jurídica', 'Observação Teste 3', 's'),
(7, 'ClienteXYZ4', 'XYZ Comércio 4 Ltda', '151.515.151/0001-15', '2024-02-01', 'Pessoa jurídica', 'Observação XYZ 4', 's'),
(8, 'ClienteABC3', 'ABC Consultoria 3 S.A.', '161.616.161/0001-16', '2024-02-01', 'Pessoa jurídica', 'Observação ABC 3', 's'),
(9, 'ClienteFinal', 'Final Comércio Ltda', '141.414.141/0001-14', '2024-01-30', 'Pessoa jurídica', 'Observação Final', 's'),
(10, 'ClienteFinal2', 'Final Comércio 2 Ltda', '191.919.191/0001-19', '2024-02-03', 'Pessoa jurídica', 'Observação Final 2', 's');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_paginas`
--

CREATE TABLE `tb_paginas` (
  `pag_codigo` int(11) NOT NULL,
  `pag_nome` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_paginas`
--

INSERT INTO `tb_paginas` (`pag_codigo`, `pag_nome`) VALUES
(1, 'Home'),
(2, 'Chamados'),
(3, 'Clientes'),
(4, 'Usuários'),
(5, 'Agendamentos'),
(6, 'Indicadores'),
(7, 'Configurações');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_paginas_usuario`
--

CREATE TABLE `tb_paginas_usuario` (
  `pag_codigo` int(11) NOT NULL,
  `usu_codigo` int(11) NOT NULL,
  `permitir` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_paginas_usuario`
--

INSERT INTO `tb_paginas_usuario` (`pag_codigo`, `usu_codigo`, `permitir`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 1),
(4, 1, 1),
(5, 1, 1),
(6, 1, 1),
(7, 1, 1),
(1, 1, 1),
(2, 2, 1),
(3, 2, 0),
(4, 2, 0),
(5, 2, 1),
(6, 2, 0),
(7, 2, 0),
(1, 3, 0),
(2, 3, 0),
(3, 3, 0),
(4, 3, 0),
(5, 3, 0),
(6, 3, 0),
(7, 3, 0),
(1, 4, 0),
(2, 4, 0),
(3, 4, 0),
(4, 4, 0),
(5, 4, 0),
(6, 4, 0),
(7, 4, 0),
(1, 5, 0),
(2, 5, 0),
(3, 5, 0),
(4, 5, 0),
(5, 5, 0),
(6, 5, 0),
(7, 5, 0),
(1, 6, 0),
(2, 6, 0),
(3, 6, 0),
(4, 6, 0),
(5, 6, 0),
(6, 6, 0),
(7, 6, 0),
(1, 7, 0),
(2, 7, 0),
(3, 7, 0),
(4, 7, 0),
(5, 7, 0),
(6, 7, 0),
(7, 7, 0),
(1, 8, 0),
(2, 8, 0),
(3, 8, 0),
(4, 8, 0),
(5, 8, 0),
(6, 8, 0),
(7, 8, 0),
(1, 9, 0),
(2, 9, 0),
(3, 9, 0),
(4, 9, 0),
(5, 9, 0),
(6, 9, 0),
(7, 9, 0),
(1, 10, 0),
(2, 10, 0),
(3, 10, 0),
(4, 10, 0),
(5, 10, 0),
(6, 10, 0),
(7, 10, 0),
(1, 11, 0),
(2, 11, 0),
(3, 11, 0),
(4, 11, 0),
(5, 11, 0),
(6, 11, 0),
(7, 11, 0),
(1, 12, 0),
(2, 12, 0),
(3, 12, 0),
(4, 12, 0),
(5, 12, 0),
(6, 12, 0),
(7, 12, 0),
(1, 13, 0),
(2, 13, 0),
(3, 13, 0),
(4, 13, 0),
(5, 13, 0),
(6, 13, 0),
(7, 13, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_usuario`
--

CREATE TABLE `tb_usuario` (
  `usu_codigo` int(11) NOT NULL,
  `usu_nome` varchar(255) NOT NULL,
  `usu_email` varchar(255) NOT NULL,
  `usu_senha` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`usu_codigo`, `usu_nome`, `usu_email`, `usu_senha`) VALUES
(1, 'Admin', 'brenda.mais99@gmail.com', 'brenda123'),
(2, 'User', 'brenda_mais@hotmail.com', 'abc123'),
(3, 'Lucas', 'lucas.silva@example.com', 'lucas123'),
(4, 'Maria', 'maria.rodrigues@example.com', 'maria456'),
(5, 'Pedro', 'pedro.oliveira@example.com', 'pedro789'),
(6, 'Camila', 'camila.santos@example.com', 'camila123'),
(7, 'Rodrigo', 'rodrigo.almeida@example.com', 'rodrigo456'),
(9, 'Fernanda', 'fernanda.souza@example.com', 'fernanda123'),
(10, 'Ricardo', 'ricardo.pereira@example.com', 'ricardo456'),
(11, 'Amanda', 'amanda.alves@example.com', 'amanda789'),
(12, 'Carlos', 'carlos.santana@example.com', 'carlos123'),
(13, 'Isabela', 'isabela.rocha@example.com', 'isabela456');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_chamados`
--
ALTER TABLE `tb_chamados`
  ADD PRIMARY KEY (`cha_codigo`),
  ADD KEY `fk_pes_codigo` (`pes_codigo`),
  ADD KEY `fk_usu_codigo` (`usu_codigo`);

--
-- Índices de tabela `tb_chamados_interacao`
--
ALTER TABLE `tb_chamados_interacao`
  ADD PRIMARY KEY (`chi_codigo`),
  ADD KEY `fk_cha_codigo` (`cha_codigo`);

--
-- Índices de tabela `tb_cliente`
--
ALTER TABLE `tb_cliente`
  ADD PRIMARY KEY (`pes_codigo`);

--
-- Índices de tabela `tb_paginas`
--
ALTER TABLE `tb_paginas`
  ADD PRIMARY KEY (`pag_codigo`);

--
-- Índices de tabela `tb_paginas_usuario`
--
ALTER TABLE `tb_paginas_usuario`
  ADD KEY `pag_codigo` (`pag_codigo`),
  ADD KEY `usu_codigo` (`usu_codigo`);

--
-- Índices de tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD PRIMARY KEY (`usu_codigo`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_chamados`
--
ALTER TABLE `tb_chamados`
  MODIFY `cha_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `tb_chamados_interacao`
--
ALTER TABLE `tb_chamados_interacao`
  MODIFY `chi_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;

--
-- AUTO_INCREMENT de tabela `tb_cliente`
--
ALTER TABLE `tb_cliente`
  MODIFY `pes_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `tb_paginas`
--
ALTER TABLE `tb_paginas`
  MODIFY `pag_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  MODIFY `usu_codigo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_chamados`
--
ALTER TABLE `tb_chamados`
  ADD CONSTRAINT `fk_pes_codigo` FOREIGN KEY (`pes_codigo`) REFERENCES `tb_cliente` (`pes_codigo`),
  ADD CONSTRAINT `fk_usu_codigo` FOREIGN KEY (`usu_codigo`) REFERENCES `tb_usuario` (`usu_codigo`);

--
-- Restrições para tabelas `tb_chamados_interacao`
--
ALTER TABLE `tb_chamados_interacao`
  ADD CONSTRAINT `fk_cha_codigo` FOREIGN KEY (`cha_codigo`) REFERENCES `tb_chamados` (`cha_codigo`);

--
-- Restrições para tabelas `tb_paginas_usuario`
--
ALTER TABLE `tb_paginas_usuario`
  ADD CONSTRAINT `tb_paginas_usuario_ibfk_1` FOREIGN KEY (`pag_codigo`) REFERENCES `tb_paginas` (`pag_codigo`),
  ADD CONSTRAINT `tb_paginas_usuario_ibfk_2` FOREIGN KEY (`usu_codigo`) REFERENCES `tb_usuario` (`usu_codigo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
