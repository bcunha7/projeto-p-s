<select name="usu_codigo" class="select-box select-dropdown">
    <?php foreach ($usuarios as $usuario) : ?>
        <option value="<?php echo $usuario['usu_codigo']; ?>" <?php echo ($tecnico == $usuario['usu_codigo']) ? 'selected' : ''; ?>>
            <?php echo $usuario['usu_nome']; ?>
        </option>
    <?php endforeach; ?>
</select>
