<label for="cha_status" class="label">Status:</label>
<select name="cha_status" class="filtro-dropdown">
    <option value="">Selecionar status</option> <!-- Opção em branco -->
    <?php foreach ($statusOptions as $numero => $statusTexto) { ?>
        <option value="<?php echo $numero; ?>" <?php echo ($status == $numero) ? 'selected' : ''; ?>>
            <?php echo $statusTexto; ?>
        </option>
    <?php } ?>
</select>