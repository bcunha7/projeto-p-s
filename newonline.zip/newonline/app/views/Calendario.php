<?php
class Calendario {

    private $active_year, $active_month, $active_day;

    public function __construct($year = null) {
        $this->active_year = $year != null ? $year : date('Y');
        $this->active_month = isset($_GET['month']) ? $_GET['month'] : date('m');
        $this->active_day = date('d');
    }

    public function getNomeMes($mes) {
        $nomesMeses = [
            1 => 'Janeiro',
            2 => 'Fevereiro',
            3 => 'Março',
            4 => 'Abril',
            5 => 'Maio',
            6 => 'Junho',
            7 => 'Julho',
            8 => 'Agosto',
            9 => 'Setembro',
            10 => 'Outubro',
            11 => 'Novembro',
            12 => 'Dezembro'
        ];

        return $nomesMeses[$mes];
    }

    public function imprimirCalendario($chamadosAgendados) {

        $num_days = date('t', strtotime($this->active_day . '-' . $this->active_month . '-' . $this->active_year));
        $num_days_last_month = date('j', strtotime('last day of previous month', strtotime($this->active_day . '-' . $this->active_month . '-' . $this->active_year)));

        $days = [0 => 'Dom', 1 => 'Seg', 2 => 'Ter', 3 => 'Qua', 4 => 'Qui', 5 => 'Sex', 6 => 'Sáb'];

        $first_day_of_week = strftime('%u', strtotime($this->active_year . '-' . $this->active_month . '-2')) % 7;
        $html = '';
        $html .= '<div class="calendar">';
        $html .= '<div class="header">';
        $html .= '<div class="navigation">';
        $html .= '<h2> Calendário </h2>';
        $html .= '<div class="container">';
        $html .= '<select onchange="window.location.href = \'?year=' . $this->active_year . '&month=\' + this.value;">';
        for ($month = 1; $month <= 12; $month++) {
            $selected = ($this->active_month == $month) ? ' selected' : '';
            $html .= '<option value="' . $month . '"' . $selected . '>' . $this->getNomeMes($month) . '</option>';
        }
        $html .= '</select>';
        $html .= '<select onchange="window.location.href = \'?year=\' + this.value + \'&month=' . $this->active_month . '\';">';
        for ($year = date('Y'); $year >= (date('Y') - 10); $year--) {
            $html .= '<option value="' . $year . '"' . ($this->active_year == $year ? ' selected' : '') . '>' . $year . '</option>';
        }
        $html .= '</select>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '<div class="calendar-container">';
        $html .= '<div class="calendar with-wrap">';
        $html .= '<div class="days">';
        foreach ($days as $day) {
            $html .= '<div class="day_name">' . $day . '</div>';
        }

        $num_days_last_month_display = ($first_day_of_week - 1 + 7) % 7;
        for ($i = 1; $i <= $num_days_last_month_display; $i++) {
            $html .= '<div class="day_num ignore">' . ($num_days_last_month - $num_days_last_month_display + $i) . '</div>';
        }

        for ($i = 1; $i <= $num_days; $i++) {
            $selected = '';
            $hasAgendamento = false;
            $chamadosAgendadosNoDia = [];

            $dataAtual = sprintf('%04d-%02d-%02d', $this->active_year, $this->active_month, $i);
            if (isset($chamadosAgendados[$dataAtual])) {
                $hasAgendamento = true;
                $chamadosAgendadosNoDia = $chamadosAgendados[$dataAtual];
            }

            if ($i == $this->active_day) {
                $selected = ' selected';
            }

            $html .= '<div class="day_num' . $selected . ($hasAgendamento ? ' has_agendamento' : '') . '">';
            $html .= '<span class="day_number">' . $i . '</span>';
            if ($hasAgendamento) {
                foreach ($chamadosAgendadosNoDia as $chamado) {
                    $html .= '<a href="editar_chamado.php?cha_codigo=' . $chamado . '">';
                    $html .= '<div class="chamado_numero"> Chamado: ' . $chamado . '</div>';
                    $html .= '</a>';
                }
            } 

            $html .= '</div>';
        }

        $remaining_days = 35 - $num_days - $num_days_last_month_display;
        for ($i = 1; $i <= $remaining_days; $i++) {
            $html .= '<div class="day_num ignore">' . $i . '</div>';
        }

        $html .= '</div>';
        
        return $html;
        }
}

