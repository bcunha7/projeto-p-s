<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  </head>
  <body>
    <div style="width: 500px;">
      <canvas id="myChart"></canvas>
    </div>
  
    <?php
        include_once 'app/controllers/ChamadoController.php';

        $chamadoController = new ChamadoController(); // Ajuste o modelo conforme necessário
        $selectedYear2 = isset($_GET['year2']) ? $_GET['year2'] : date('Y'); 
        $chartData = $chamadoController->getChartData($selectedYear2);

      echo '<script>';
      echo 'const labels = ' . $chartData['labels'] . ';';
      echo 'const data = {';
      echo '  labels: labels,';
      echo '  datasets: [{';
      echo '    label: "Contagem de chamados agrupados por mês",';
      echo '    data: ' . $chartData['amount'] . ',';
      echo '    backgroundColor: [';
      echo '      "rgba(255, 99, 132, 0.2)",';
      echo '      "rgba(255, 159, 64, 0.2)",';
      echo '      "rgba(255, 205, 86, 0.2)",';
      echo '      "rgba(75, 192, 192, 0.2)",';
      echo '      "rgba(54, 162, 235, 0.2)",';
      echo '      "rgba(153, 102, 255, 0.2)",';
      echo '      "rgba(201, 203, 207, 0.2)"';
      echo '    ],';
      echo '    borderColor: [';
      echo '      "rgb(255, 99, 132)",';
      echo '      "rgb(255, 159, 64)",';
      echo '      "rgb(255, 205, 86)",';
      echo '      "rgb(75, 192, 192)",';
      echo '      "rgb(54, 162, 235)",';
      echo '      "rgb(153, 102, 255)",';
      echo '      "rgb(201, 203, 207)"';
      echo '    ],';
      echo '    borderWidth: 1';
      echo '  }]';
      echo '};';
      echo 'const config = {';
      echo '  type: "bar",';
      echo '  data: data,';
      echo '  options: {';
      echo '    scales: {';
      echo '      y: {';
      echo '        beginAtZero: true';
      echo '      }';
      echo '    }';
      echo '  }';
      echo '};';
      echo 'var myChart = new Chart(document.getElementById("myChart"), config);';
      echo '</script>';

    ?>
  </body>
</html>