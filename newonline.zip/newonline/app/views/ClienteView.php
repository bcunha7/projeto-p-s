<select name="pes_codigo" class="select-box select-dropdown">
    <?php foreach ($dadosClientes as $cliente): ?>
        <option value="<?php echo $cliente['pes_codigo']; ?>" <?php echo (isset($selectedCliente) && $cliente['pes_codigo'] == $selectedCliente) ? 'selected' : ''; ?>>
            <?php echo $cliente['pes_fantasia']; ?>
        </option>
    <?php endforeach; ?>
</select>