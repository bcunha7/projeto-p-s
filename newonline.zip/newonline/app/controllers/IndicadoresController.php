<?php
class IndicadoresController {
    public function exibirIndicadores() {
        $chamadoModel = new ChamadoModel();

        include 'app/views/indicadores.php';
    }
}

$indicadoresController = new IndicadoresController();
$indicadoresController->exibirIndicadores();
