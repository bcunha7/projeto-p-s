<?php

require_once 'app/models/UsuarioModel.php';

class UsuarioController {
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new UsuarioModel();
    }
    public function cadastrarUsuario(): bool {

        $this->usuarioModel->setFormDados($_POST);

        return $this->usuarioModel->cadastrarUsuario();
    }
    public function editarUsuario($usu_codigo): bool {

        $this->usuarioModel->setFormDados($_POST);

        return $this->usuarioModel->editarUsuario($usu_codigo);
    }
    public function excluirUsuario($usu_codigo): bool {

        if (!is_numeric($usu_codigo)) {
            // Se o ID não for válido, retorna uma resposta de erro
            return false;
        }
    
        $this->usuarioModel->setFormCodigo($usu_codigo);
    
        $sucesso = $this->usuarioModel->excluirUsuario($usu_codigo);
    
        // Retorna true apenas se ambas as operações forem bem-sucedidas
        return $sucesso;
    }

    public function excluirPermissaoPaginasPorUsuario($usu_codigo): bool {
        
    
        return $this->usuarioModel->excluirPermissaoPaginasPorUsuario($usu_codigo);
    }
    
   
    public function buscarUsuarioPorCod($usu_codigo): array {
        return $this->usuarioModel->buscarUsuarioPorCod($usu_codigo);
    }
    public function pesquisarUsuario($pesquisarTermo = null) {

        $usuarioFiltrados = $this->usuarioModel->pesquisarUsuario($pesquisarTermo);

        // Exibir ou utilizar os resultados conforme necessário
        print_r($usuarioFiltrados);
    }
    public function listarUsuario() {
        // Obtém parâmetros da requisição
        $pesquisa = isset($_GET['pesquisar']) ? $_GET['pesquisar'] : '';
        $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
        // Filtra os chamados usando o modelo
        $usuarios = $this->usuarioModel->pesquisarUsuario($pesquisa);

        // Renderiza a tabela usando o modelo
        $tabelaUsuarios = $this->usuarioModel->renderizarTabelaUsuario($usuarios, $currentPage);
       
        echo  $tabelaUsuarios ;
    }

    
    public function obterUsuarios() {
        return $this->usuarioModel->opcoesTecnicos();
    }
    public function autenticarUsuario($usu_nome, $usu_senha) {
        $usu_codigo = $this->usuarioModel->autenticarUsuario($usu_nome, $usu_senha);

        return $usu_codigo;
    }
    public function processarCadastro(array $formDados) {
        if (!empty($formDados['SendCadUsuarioPg'])) {
            $this->usuarioModel->setFormDados($formDados);
            $valor = $this->usuarioModel->cadastrarUsuario();

            if ($valor) {
                echo "<script>alert('Usuario cadastrado com sucesso!'); window.location.href='pesquisa_usuario.php';</script>";
            } else {
                echo "<script>alert('Erro: Usuario não cadastrado!');</script>";
            }
        }
    }

    public function renderizarTecnicoSelect($tecnico) {
        $usuarios = $this->usuarioModel->listarUsuario();
        include 'app/views/TecnicoView.php';
    }
}