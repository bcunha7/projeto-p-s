<?php
   if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

    require 'app/controllers/UsuarioController.php';
    require 'app/controllers/PaginaController.php';


    if (isset($_POST['SendLogin'])) {
        $usu_nome = $_POST['usu_nome'];
        $usu_senha = $_POST['usu_senha'];
        $_SESSION['usu_codigo'] = $codigoDoUsuario;

        $usuarioController = new UsuarioController();

        // Obtém o código do usuário após a autenticação
        $usu_codigo = $usuarioController->autenticarUsuario($usu_nome, $usu_senha);

        if ($usu_codigo !== false) {
            $permissoesUsuario = new PaginaController();

            // Obtenha as permissões do usuário
            $permissoesUsuario = $permissoesUsuario->consultarPermissaoPaginasPorUsuario($usu_codigo);

            // Armazene as permissões na sessão
            $_SESSION['usu_codigo'] = $usu_codigo;
            $_SESSION['usu_nome'] = $usu_nome;
            $_SESSION['permissoesUsuario'] = $permissoesUsuario;

            // Redirecione para a página correta após a autenticação bem-sucedida
            header('Location: http://localhost/newonline/index.php');
            exit();
        } else {
            // Redirecione para a página de login com um parâmetro de erro
            header('Location: login.php?erro=1');
            exit();
        }
    }
