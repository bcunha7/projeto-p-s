<?php
// CalendarioController.php
require_once 'app/models/ChamadoModel.php';
require_once 'app/views/Calendario.php';

class CalendarioController {
    public function exibirCalendario($selectedYear) {
        $chamadoModel = new ChamadoModel();
        $chamadosAgendados = $chamadoModel->consultarChamadosAgendados();

        $calendarioView = new Calendario();
        $calendarioHtml = $calendarioView->imprimirCalendario($chamadosAgendados);

        // Retornar o HTML gerado para ser exibido na página
        return $calendarioHtml;
    }
}

