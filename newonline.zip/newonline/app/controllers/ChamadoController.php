<?php
    require_once 'app/models/ChamadoModel.php';
    class ChamadoController
    {
        private $model;

        public function __construct() {
            $this->model = new ChamadoModel();
        }
        public function processarCadastro(array $formDados) {
            if (!empty($formDados['SendCadChamadoPg'])) {
                $this->model->setFormDados($formDados);
                $valor = $this->model->cadastrarChamado();
    
                if ($valor) {
                    echo "<script>alert('Chamado cadastrado com sucesso!'); window.location.href='pesquisa_chamado.php';</script>";
                } else {
                    echo "<script>alert('Erro: Chamado não cadastrado!');</script>";
                }
            }
        }
        public function cadastrarChamado(): bool {
            
            $this->model->setFormDados($_POST);

            return $this->model->cadastrarChamado();
        }

        public function processarFormularioEdicaoChamado($formDados) {
            if (!empty($formDados['SendEditChamadoPg'])) {
                $cha_codigo = $_GET['cha_codigo'] ?? '';
    
                $valor = $this->editarChamado($cha_codigo, $formDados);
    
                if ($valor) {
                    echo "<script>alert('Chamado alterado com sucesso!'); ";
                    echo '<script>window.location.href = "editar_chamado.php?cha_codigo=' . $cha_codigo . '";</script>';
                } else {
                    echo "<p style='color: #ff0000;'>Erro: Falha ao alterar o chamado!</p>";
                }
            }
        }
    
        public function editarChamado($cha_codigo, $formDados): bool {
            $this->model->setFormDados($formDados);
    
            return $this->model->editarChamado($cha_codigo);
        }

        public function excluirChamado($cha_codigo): bool {
            // Validação do ID do chamado
            if (!is_numeric($cha_codigo)) {
                // Se o ID não for válido, retorna uma resposta de erro
                return false;
            }
        
            $this->model->setFormCodigo($cha_codigo);
            
            // Tenta excluir as interações e o chamado
            $sucessoInteracoes = $this->model->excluirInteracoes($cha_codigo);
            $sucessoChamado = $this->model->excluirChamado();
        
            // Retorna true apenas se ambas as operações forem bem-sucedidas
            return $sucessoInteracoes && $sucessoChamado;
        }

        public function exibirChamados() {
            $pesquisa = isset($_GET['pesquisar']) ? $_GET['pesquisar'] : '';
            $dataabertura = isset($_GET['cha_dataabertura']) ? date('Y-m-d', strtotime($_GET['cha_dataabertura'])) : '';
            $cliente = isset($_GET['pes_codigo']) ? intval($_GET['pes_codigo']) : '';
            $tecnico = isset($_GET['usu_codigo']) ? intval($_GET['usu_codigo']) : '';
            $status = isset($_GET['cha_status']) ? intval($_GET['cha_status']) : '';
    
            $chamados = $this->model->filtrarChamados($pesquisa, $dataabertura, $cliente, $tecnico, $status);
            $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
    
            // Renderizar a tabela de chamados
            $html = $this->model->renderizarTabelaChamado($chamados, $currentPage);
    
            include 'pesquisa_chamado.php';  
        }
        
        private function isValidChamadoId($cha_codigo): bool {
            return is_numeric($cha_codigo);
        }
        public function processarChamadoPorCodigo() {
            
            if (isset($_GET['cha_codigo'])) {
                $cha_codigo = $_GET['cha_codigo'];
                return $this->buscarChamadoPorCod($cha_codigo);
            }
    
            return false; 
        }
        public function buscarChamadoPorCod($cha_codigo): array {
            return $this->model->buscarChamadoPorCod($cha_codigo);
        }

        public function filtrarChamados($pesquisarTermo = null, $dataabertura = null, $cliente = null, $tecnico = null, $status = null) {
            // Filtrar chamados
            $chamadosFiltrados = $this->model->filtrarChamados($pesquisarTermo, $dataabertura, $cliente, $tecnico, $status);

            print_r($chamadosFiltrados);
        }

        private function consultarDetalhesChamado($chamadoCodigo) {
            // Consultar detalhes do chamado
            $detalhesChamado = $this->model->consultarDetalhesChamado($chamadoCodigo);

            // Exibir ou utilizar os resultados conforme necessário
            print_r($detalhesChamado);
        }

        public function consultarChamadosAgendados() {
   
            $chamadosAgendados = $this->model->consultarChamadosAgendados();

            print_r($chamadosAgendados);
        }
        public function processarFormularioInteracao() {
            $formDadosInteracao = filter_input_array(INPUT_POST, FILTER_DEFAULT);
    
            if (!empty($formDadosInteracao['SendInteracaoChamadoPg'])) {
                $cha_codigo_interacao = $_GET['cha_codigo'];
                if (!empty($cha_codigo_interacao)) {
                    $interacao_texto = $formDadosInteracao['interacao_texto'];
    
                    if (!empty($interacao_texto)) {
                        $resultado = $this->adicionarInteracao($cha_codigo_interacao, $interacao_texto, $_SESSION['usu_nome'], 0);
    
                        if ($resultado === true) {
                            echo '<script>alert("Interação adicionada com sucesso!!");</script>';
                            echo '<script>window.location.href = "editar_chamado.php?cha_codigo=' . $cha_codigo_interacao . '";</script>';
                        } else {
                            echo '<script>alert("Erro ao adicionar interação.");</script>';
                        }
                    } else {
                        echo '<script>alert("Texto da interação inválido.");</script>';
                    }
                }
            }
        }
        public function adicionarInteracao($cha_codigo, $interacao_texto, $autor, $tipointeracao) {
            // Adicionar interação
            $result = $this->model->adicionarInteracao($cha_codigo, $interacao_texto, $autor, $tipointeracao);
    
            return $result;
        }

        public function excluirInteracoes($cha_codigo) {
            // Excluir interações
            $result = $this->model->excluirInteracoes($cha_codigo);

            if ($result === true) {
                echo "Interações excluídas com sucesso!";
            } else {
                echo "Erro ao excluir interações.";
            }
        }

        public function buscarInteracoesPorChamado($cha_codigo): array {
            return $this->model->buscarInteracoesPorChamado($cha_codigo);
        }

        public function extrairCodigoChamado($assunto) {
            // Chamar a função de extração de código do chamado
            $codigoChamado = $this->model->extrairCodigoChamado($assunto);

            // Exibir ou utilizar o resultado conforme necessário
            if ($codigoChamado !== false) {
                echo "Código do Chamado: " . $codigoChamado . "<br>";
            } else {
                echo "Erro na extração do código<br>";
            }
        }

        public function notificarPorEmail($dadosChamado, $interacoes) {
    
            $result = $this->model->enviarEmailNotificacao($dadosChamado, $interacoes);

            if ($result === true) {
                echo "E-mail enviado com sucesso!";
            } else {
                echo $result;
            }
        }

        public function getInteracoesChamado($cha_codigo) {
            
            $interacoes = $this->model->getInteracoesChamado($cha_codigo);
    
        
            if ($interacoes !== false) {
                if (count($interacoes) > 0) {
                    foreach ($interacoes as $interacao) {
                        if ($interacao['tipo'] == 0) {
                            echo '<div class="message send">';
                            echo '<div class="message-date send">';
                            echo '<div class="date send">';
                            echo '<small>' . $interacao['data'] . '</small>';
                            echo '</div>';
                            echo '<div class="message-content send">';
                            echo '<p>' . $interacao['mensagem'] . '</p>';
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        } else {
                            echo '<div class="message received">';
                            echo '<div class="user received">';
                            echo '<div class="icon-circle">';
                            echo '<i class="fa-solid fa-user-secret fa-4xl" style="color: #826afb;"></i>';
                            echo '</div>';
                            echo '<div class="user-name received">';
                            echo '<small>' . $interacao['usuario'] . '</small>';
                            echo '</div>';
                            echo '</div>';
                            echo '<div class="message-date received">';
                            echo '<div class="date">';
                            echo '<small>' . $interacao['data'] . '</small>';
                            echo '</div>';
                            echo '<div class="message-content received">';
                            echo '<p>' . $interacao['mensagem'] . '</p>';
                            echo '</div>';
                            echo '</div>';
                            echo '</div>';
                        }
                    }
                } else {
                    echo "Nenhuma interação encontrada para esse chamado.";
                }
            } else {
                echo "Erro na obtenção das interações do chamado<br>";
            }
        }

        public function listarChamados() {
            // Obtém parâmetros da requisição
            $pesquisa = isset($_GET['pesquisar']) ? $_GET['pesquisar'] : '';
            $dataabertura = isset($_GET['cha_dataabertura']) ? date('Y-m-d', strtotime($_GET['cha_dataabertura'])) : '';
            $cliente = isset($_GET['pes_codigo']) ? intval($_GET['pes_codigo']) : '';
            $tecnico = isset($_GET['usu_codigo']) ? intval($_GET['usu_codigo']) : '';
            $status = isset($_GET['cha_status']) ? intval($_GET['cha_status']) : '';
            $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
    
            // Filtra os chamados usando o modelo
            $chamados = $this->model->filtrarChamados($pesquisa, $dataabertura, $cliente, $tecnico, $status);
    
            // Renderiza a tabela usando o modelo
            $tabelaChamados = $this->model->renderizarTabelaChamado($chamados, $currentPage, 11);
           
            echo $tabelaChamados;
        }
        /////INDICADORES/////
        public function getChartData($year) {   
            // Chamar a função para obter dados do gráfico
            $chartData = $this->model->getChartData($year);
        
            // Exibir ou utilizar o resultado conforme necessário
            if ($chartData !== false) {
                $labels = $chartData['labels']; // Assuming $chartData is an associative array with 'labels' key
                $amount = $chartData['amount']; // Assuming $chartData is an associative array with 'amount' key
        
                return [
                    'labels' => $labels,
                    'amount' => $amount,
                ];
            } else {
                return "Erro na obtenção dos dados do gráfico<br>";
            }
        }
        

        public function getTotalChamados($year, $month) {
            // Chamar a função para obter o total de chamados
            $totalChamados = $this->model->getTotalChamados($year, $month);
    
            // Exibir ou utilizar o resultado conforme necessário
            if ($totalChamados !== false) {
                return $totalChamados;
            } else {
                return "Erro";
            }
        }

        public function getChamadosAbertos($year, $month) {
            // Chamar a função para obter o total de chamados
            $totalChamadosAbertos = $this->model->getChamadosAbertos($year, $month);
    
            // Exibir ou utilizar o resultado conforme necessário
            if ($totalChamadosAbertos !== false) {
                return $totalChamadosAbertos;
            } else {
                return "Erro";
            }
        }

        public function getChamadosAndamento($year, $month) {
            // Chamar a função para obter o total de chamados
            $totalChamadosAndamento = $this->model->getChamadosAndamento($year, $month);
    
            // Exibir ou utilizar o resultado conforme necessário
            if ($totalChamadosAndamento !== false) {
                return $totalChamadosAndamento;
            } else {
                return "Erro";
            }
        }

        public function getChamadosFechados($year, $month) {
            // Chamar a função para obter o total de chamados
            $totalChamadosFechados = $this->model->getChamadosFechados($year, $month);

            // Exibir ou utilizar o resultado conforme necessário
            if ($totalChamadosFechados !== false) {
                return $totalChamadosFechados;
            } else {
                return "Erro";
            }
        }

        public function getChamadosAgendados($year, $month) {
            //Chamar a função para obter o total de chamados
            $totalChamadosAgendados = $this->model->getChamadosAgendados($year, $month);

            // Exibir ou utilizar o resultado conforme necessário
            if ($totalChamadosAgendados !== false) {
                return $totalChamadosAgendados;
            } else {
                return "Erro";
            }
        }
    }