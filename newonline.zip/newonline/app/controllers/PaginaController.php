<?php
    require 'app/models/PaginaModel.php';
    class PaginaController {
        private $paginaModel;
        public function __construct() {
            $this->paginaModel = new PaginaModel();
        }
        public function cadastrarPermissao($usu_codigo): bool {

            $this->paginaModel->setFormDados($_POST);
    
            return $this->paginaModel->cadastrarPermissaoPaginas($usu_codigo);
        }
        public function editarPermissao($pag_codigo, $usu_codigo, $permitir): bool {

            $this->paginaModel->setFormDados($_POST);
    
            return $this->paginaModel->editarPermissao($pag_codigo, $usu_codigo, $permitir);
        }
        public function consultarPermissoes($usu_codigo) {
            return $this->paginaModel->consultarPermissoes($usu_codigo);
        }
        public function verificarSessao() {
            if (session_status() == PHP_SESSION_NONE) {
                session_start();
            }
    
            return isset($_SESSION['usu_codigo']);
        }
        public function consultarPermissaoPaginas() {
            return $this->paginaModel->consultarPermissaoPaginas();
        }
        
        public function listarPaginas($usu_codigo) {
            $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
        
            // Filtra os chamados usando o modelo
            $paginas = $this->paginaModel->consultarPermissaoPaginasPorUsuario($usu_codigo);
        
            // Renderiza a tabela usando o modelo
            $tabelaUsuarios = $this->paginaModel->renderizarTabelaPermitir($paginas, $currentPage);
        
            echo  $tabelaUsuarios;
        }
    
        public function consultarPermissaoPaginasPorUsuario($usu_codigo) {
            return $this->paginaModel->consultarPermissaoPaginasPorUsuario($usu_codigo);
        }
        
        public function consultarNomePagina($pag_codigo) {
            return $this->paginaModel->consultarNomePagina($pag_codigo);
        }
        public function exibirMenu($paginasMapeadas) {

            if (isset($_SESSION['usu_codigo'])) {
                $usu_codigo = $_SESSION['usu_codigo'];
                
                $paginasUsuario = $this->consultarPermissoes($usu_codigo); // Use $this
                $_SESSION['permissoesUsuario'] = $paginasUsuario;
        
                include 'menu.php';
            } else {
                header('Location: indicadores.php');
                exit();
            }
        }
        
    }