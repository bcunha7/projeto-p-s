<?php

require 'app/models/StatusModel.php';

class StatusController {
    private $statusModel;

    public function __construct() {
        $this->statusModel = new StatusModel();
    }

    public function renderizarStatusSelect($status) {
        $statusOptions = $this->statusModel->getStatusOptions();
        include 'app/views/StatusView.php';
    }
}
