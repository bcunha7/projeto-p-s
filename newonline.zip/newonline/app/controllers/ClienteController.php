<?php

require_once 'app/models/ClienteModel.php';

class ClienteController {
    private $clienteModel;

    public function __construct() {
        $this->clienteModel = new ClienteModel();
    }

    public function cadastrarCliente(): bool {

        $this->clienteModel->setFormDados($_POST);

        return $this->clienteModel->cadastrarCliente();
    }
    public function editarCliente($pes_codigo): bool {

        $this->clienteModel->setFormDados($_POST);

        return $this->clienteModel->editarCliente($pes_codigo);
    }
    public function excluirCliente($pes_codigo): bool {

        if (!is_numeric($pes_codigo)) {
            // Se o ID não for válido, retorna uma resposta de erro
            return false;
        }
    
        $this->clienteModel->setFormCodigo($pes_codigo);
    
        $sucesso = $this->clienteModel->excluirCliente($pes_codigo);
    
        // Retorna true apenas se ambas as operações forem bem-sucedidas
        return $sucesso;
    }
    public function buscarClientePorCod($pes_codigo): array {
        return $this->clienteModel->buscarClientePorCod($pes_codigo);
    }
    public function pesquisarCliente($pesquisarTermo = null) {
        // Filtrar chamados
        $clienteFiltrados = $this->clienteModel->pesquisarCliente($pesquisarTermo);

        print_r($clienteFiltrados);
    }
    public function obterClientes() {
        return $this->clienteModel->opcoesClientes();
    }
    public function listarCliente() {
        // Obtém parâmetros da requisição
        $pesquisa = isset($_GET['pesquisar']) ? $_GET['pesquisar'] : '';
        $currentPage = isset($_GET['page']) ? intval($_GET['page']) : 1;
        // Filtra os chamados usando o modelo
        $clientes = $this->clienteModel->pesquisarCliente($pesquisa);

        // Renderiza a tabela usando o modelo
        $tabelaClientes = $this->clienteModel->renderizarTabelaCliente($clientes, $currentPage);
       
        echo  $tabelaClientes ;
    }

    public function processarCadastro(array $formDados)
    {
        if (!empty($formDados['SendCadClientePg'])) {
            $this->clienteModel->setFormDados($formDados);
            $valor = $this->clienteModel->cadastrarCliente();

            if ($valor) {
                echo "<script>alert('Cliente cadastrado com sucesso!'); window.location.href='pesquisa_cliente.php';</script>";
            } else {
                echo "<script>alert('Erro: Cliente não cadastrado!');</script>";
            }
        }
    }

    public function processarEdicao(array $formDados, $pes_codigo) {
        $clienteModel = new ClienteModel();
        $clienteModel->setFormDados($formDados);
        $valor = $clienteModel->editarCliente($pes_codigo);
    
        if ($valor) {
            header("Location: pesquisa.php");
            exit();
        } else {
            echo "<script>alert('Erro: Não foi possível salvar a edição!');</script>";
        }
    }
    
    public function exibirFormularioEdicao($pes_codigo) {
        $clienteModel = new ClienteModel();
        $dados_cliente = $clienteModel->buscarClientePorCod($pes_codigo);

        if ($dados_cliente) {
            include 'editar_cliente.php';
        } else {
            echo "Cliente não encontrado.";
        }
    }
public function renderizarClienteSelect($selectedCliente = null) {
    $dadosClientes = $this->clienteModel->listarCliente();
    include 'app/views/ClienteView.php';
}
}
