<?php
class ChartData
    {
        private $month = [];
        private $amount = [];
    
        public function __construct($data)
        {
            foreach ($data as $item) {
                $this->month[] = $item['monthname'];
                $this->amount[] = $item['amount'];
            }
        }
    
        public function getMonthData()
        {
            return json_encode($this->month);
        }
    
        public function getAmountData()
        {
            return json_encode($this->amount);
        }
    }
    