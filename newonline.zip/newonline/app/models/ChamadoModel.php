<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'C:\xampp\htdocs\newonline\PHPMailer\src\Exception.php';
    require 'C:\xampp\htdocs\newonline\PHPMailer\src\PHPMailer.php';
    require 'C:\xampp\htdocs\newonline\PHPMailer\src\SMTP.php';

    require_once 'app/models/ChamadoModel.php';
    class ChamadoModel extends Conexao
    {
        private array $formDados;
        private int $formCodigo; 
        private object $conn;

        public function __construct() {
            $this->conn = $this->conectar();
        }
        public function setFormDados(array $formDados): void {
            $this->formDados = $formDados;
        }

        public function setFormCodigo(int $formCodigo): void {
            $this->formCodigo = $formCodigo;
        }

        public function cadastrarChamado(): bool {
            $query_chamado = "INSERT INTO tb_chamados
                    (cha_assunto, cha_contato, cha_telefone, cha_email, cha_dataabertura, cha_dataagendamento, cha_status, pes_codigo, usu_codigo, cha_agendado, cha_obsagendamento, cha_detalhes)
                    VALUES (:cha_assunto, :cha_contato, :cha_telefone, :cha_email, NOW(), :cha_dataagendamento, 0, :pes_codigo, :usu_codigo, :cha_agendado, :cha_obsagendamento, :cha_detalhes)";
            $cad_chamado = $this->conn->prepare($query_chamado);

            $cad_chamado->bindParam(':cha_assunto', $this->formDados['cha_assunto']);
            $cad_chamado->bindParam(':cha_contato', $this->formDados['cha_contato']);
            $cad_chamado->bindParam(':cha_telefone', $this->formDados['cha_telefone']);
            $cad_chamado->bindParam(':cha_email', $this->formDados['cha_email']);
            $cad_chamado->bindParam(':cha_dataagendamento', $this->formDados['cha_dataagendamento']);
            $cad_chamado->bindParam(':pes_codigo', $this->formDados['pes_codigo']);
            $cad_chamado->bindParam(':usu_codigo', $this->formDados['usu_codigo']);
            $cad_chamado->bindParam(':cha_agendado', $this->formDados['cha_agendado']);
            $cad_chamado->bindParam(':cha_obsagendamento', $this->formDados['cha_obsagendamento']);
            $cad_chamado->bindParam(':cha_detalhes', $this->formDados['cha_detalhes']);

            $cad_chamado->execute();

            return $cad_chamado->rowCount() > 0;
        }

        public function editarChamado($cha_codigo): bool {
            try {
                $query_chamado = "UPDATE tb_chamados
                    SET cha_status = :cha_status, cha_assunto = :cha_assunto, cha_contato = :cha_contato, 
                    cha_email = :cha_email, cha_telefone = :cha_telefone, pes_codigo = :pes_codigo, 
                    usu_codigo = :usu_codigo, cha_detalhes = :cha_detalhes, cha_agendado = :cha_agendado, 
                    cha_dataagendamento = :cha_dataagendamento, cha_obsagendamento = :cha_obsagendamento
                    WHERE cha_codigo = :cha_codigo";

                $editar_chamado = $this->conn->prepare($query_chamado);

                $editar_chamado->bindParam(':cha_status', $this->formDados['cha_status']);
                $editar_chamado->bindParam(':cha_assunto', $this->formDados['cha_assunto']);
                $editar_chamado->bindParam(':cha_contato', $this->formDados['cha_contato']);
                $editar_chamado->bindParam(':cha_email', $this->formDados['cha_email']);
                $editar_chamado->bindParam(':cha_telefone', $this->formDados['cha_telefone']);
                $editar_chamado->bindParam(':pes_codigo', $this->formDados['pes_codigo']);
                $editar_chamado->bindParam(':usu_codigo', $this->formDados['usu_codigo']);
                $editar_chamado->bindParam(':cha_detalhes', $this->formDados['cha_detalhes']);
                $editar_chamado->bindParam(':cha_agendado', $this->formDados['cha_agendado']);
                $editar_chamado->bindParam(':cha_dataagendamento', $this->formDados['cha_dataagendamento']);
                $editar_chamado->bindParam(':cha_obsagendamento', $this->formDados['cha_obsagendamento']);
                $editar_chamado->bindParam(':cha_codigo', $cha_codigo);
                $editar_chamado->execute();

                if ($editar_chamado->rowCount()) {
                    if ($this->formDados['cha_status'] <> 1) {
                        $interacoes = $this->buscarInteracoesPorChamado($cha_codigo);
                        $this->enviarEmailNotificacao($this->buscarChamadoPorCod($cha_codigo), $interacoes);
                    }

                    return true;
                } else {
                    return false;
                }
            } catch (PDOException $e) {
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }

        public function excluirChamado(): bool {
            $this->conn = $this->conectar();
            $query_chamado = "DELETE FROM tb_chamados WHERE cha_codigo = :cha_codigo";

            $excluir_chamado = $this->conn->prepare($query_chamado);
            $excluir_chamado->bindParam(':cha_codigo', $this->formCodigo, PDO::PARAM_INT);
            $excluir_chamado->execute();

            return $excluir_chamado->rowCount() > 0;
        }

        public function buscarChamadoPorCod($cha_codigo): array {
            $this->conn = $this->conectar();
            $query_chamado = "SELECT * FROM tb_chamados WHERE cha_codigo = :cha_codigo";

            $buscar_chamado = $this->conn->prepare($query_chamado);
            $buscar_chamado->bindParam(':cha_codigo', $cha_codigo, PDO::PARAM_INT);
            $buscar_chamado->execute();
            $chamado = $buscar_chamado->fetch(PDO::FETCH_ASSOC);

            return $chamado;
        }

        public function filtrarChamados($pesquisarTermo = null, $dataabertura = null, $cliente = null, $tecnico = null, $status = null) {
            try {
                $this->conn = $this->conectar();
                $query_chamado = "SELECT * FROM tb_chamados WHERE 1";
            
                if (!empty($pesquisarTermo)) {
                    $query_chamado .= " AND (cha_assunto LIKE :pesquisarTermo OR cha_contato LIKE :pesquisarTermo OR cha_email LIKE :pesquisarTermo)";
                }
            
                if (!empty($dataabertura)) {
                    $query_chamado .= " AND cha_dataabertura >= :dataabertura AND cha_dataabertura < DATE_ADD(:dataabertura, INTERVAL 1 DAY)";
                }
            
                if (!empty($cliente)) {
                    $query_chamado .= " AND pes_codigo = :cliente";
                }
            
                if (!empty($tecnico)) {
                    $query_chamado .= " AND usu_codigo = :tecnico";
                }
            
                if (!empty($status)) {
                    $query_chamado .= " AND cha_status = :status";
                }
        
                $result_chamado = $this->conn->prepare($query_chamado);
            
                if (!empty($pesquisarTermo)) {
                    $result_chamado->bindValue(':pesquisarTermo', '%' . $pesquisarTermo . '%', PDO::PARAM_STR);
                }
            
                if (!empty($dataabertura)) {
                    $result_chamado->bindValue(':dataabertura', $dataabertura);
                }
            
                if (!empty($cliente)) {
                    $result_chamado->bindValue(':cliente', $cliente);
                }
            
                if (!empty($tecnico)) {
                    $result_chamado->bindValue(':tecnico', $tecnico);
                }
            
                if (!empty($status)) {
                    $result_chamado->bindValue(':status', $status);
                }
            
                $result_chamado->execute();
                $retorno = $result_chamado->fetchAll(PDO::FETCH_ASSOC);
            
                return $retorno;
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return [];
            }
        }
    
        private function consultarDetalhesChamado($chamadoCodigo) {
            try {
                $this->conn = $this->conectar();
                $query_detalhes = "SELECT cha_codigo, cha_assunto, cha_contato FROM tb_chamados WHERE cha_codigo = :cha_codigo";
                $result = $this->conn->prepare($query_detalhes);
                $result->bindParam(':cha_codigo', $chamadoCodigo);
                $result->execute();
            
                return $result->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return [];
            }
        }

        public function consultarChamadosAgendados() {
            try {
                $this->conn = $this->conectar();
                $query_chamados = "SELECT DATE(cha_dataagendamento) AS data_agendamento, GROUP_CONCAT(cha_codigo) AS chamados FROM tb_chamados WHERE cha_dataagendamento IS NOT NULL GROUP BY data_agendamento";
                $result = $this->conn->prepare($query_chamados);
                $result->execute();
            
                $chamadosAgendados = $result->fetchAll(PDO::FETCH_ASSOC);
                $agendamentos = [];
                foreach ($chamadosAgendados as $chamado) {
                    $agendamentos[$chamado['data_agendamento']] = explode(',', $chamado['chamados']);
                }
            
                return $agendamentos;
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return [];
            }
        }

        public function adicionarInteracao($cha_codigo, $interacao_texto, $autor, $tipointeracao): bool {
            try {
                $this->conn = $this->conectar();

                $query_interacao = "INSERT INTO tb_chamados_interacao (cha_codigo, chi_comentario, chi_autor, chi_data, chi_interacaointerna)
                                            VALUES (:cha_codigo, :chi_comentario, :chi_autor, NOW(), :chi_interacaointerna)";
                
                $cad_interacao = $this->conn->prepare($query_interacao);
                
                if ($cad_interacao === false) {
                    die('Erro na preparação da consulta: ' . $this->conn->error);
                }
                
                $cad_interacao->bindValue(':cha_codigo', $cha_codigo);
                $cad_interacao->bindValue(':chi_comentario', $interacao_texto, PDO::PARAM_STR);
                $cad_interacao->bindValue(':chi_autor', $autor, PDO::PARAM_STR);
                $cad_interacao->bindValue(':chi_interacaointerna', $tipointeracao, PDO::PARAM_STR);

                $executou = $cad_interacao->execute();

                if ($executou and $tipointeracao == 0) {
                    // Se a interação foi adicionada com sucesso, enviar e-mail de notificação
                    $interacoes = $this->buscarInteracoesPorChamado($cha_codigo); // Implemente essa função conforme necessário
                    $this->enviarEmailNotificacao($this->buscarChamadoPorCod($cha_codigo), $interacoes);
                }
                
                return true;
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            } catch (Exception $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no envio do e-mail: " . $e->getMessage();
                return false;
            }
        }

        public function excluirInteracoes($cha_codigo): bool {
            try {
                $this->conn = $this->conectar();
                $query_interacao = "DELETE FROM tb_chamados_interacao WHERE cha_codigo = :cha_codigo";
            
                $excluir_interacao = $this->conn->prepare($query_interacao);
                $excluir_interacao->bindParam(':cha_codigo', $cha_codigo, PDO::PARAM_INT);
                $excluir_interacao->execute();
            
                return $excluir_interacao->rowCount() > 0;
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }

        public function buscarInteracoesPorChamado($cha_codigo): array {
            $this->conn = $this->conectar();
            $query_interacoes = "SELECT * FROM tb_chamados_interacao WHERE cha_codigo = :cha_codigo ORDER BY chi_data DESC";
            $buscar_interacoes = $this->conn->prepare($query_interacoes);
            $buscar_interacoes->bindParam(':cha_codigo', $cha_codigo, PDO::PARAM_INT);
            $buscar_interacoes->execute();
            $interacoes = $buscar_interacoes->fetchAll(PDO::FETCH_ASSOC);

            return $interacoes;
        }
        public function extrairCodigoChamado($assunto) {
            try {
                // Encontrar a posição do primeiro colchete
                $inicioColchete = strpos($assunto, "[");

                if ($inicioColchete !== false) {
                    // Encontrar a posição do último colchete
                    $fimColchete = strpos($assunto, "]", $inicioColchete);

                    if ($fimColchete !== false) {
                        // Extrair o número entre colchetes
                        $codigoChamado = substr(
                            $assunto,
                            $inicioColchete + 1, // Adicionando 1 para começar após o colchete de abertura
                            $fimColchete - $inicioColchete - 1 // Subtraindo 1 para excluir o colchete de fechamento
                        );

                        // Retornar o número do chamado
                        return $codigoChamado;
                    } else {
                        throw new Exception("Erro: Colchete de fechamento não encontrado");
                    }
                } else {
                    throw new Exception("Erro: Colchete de abertura não encontrado");
                }
            } catch (Exception $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro na extração do código: " . $e->getMessage() . "<br>";
                return false;
            }
        }

        private function configurarEmail(): PHPMailer {
            // Configurar as informações do servidor SMTP
            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host       = 'smtp-mail.outlook.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'network-online@outlook.com.br';
            $mail->Password   = 'Ironman0203!';
            $mail->SMTPSecure = 'TLS';
            $mail->Port       = 587;

            return $mail;
        }

        public function enviarEmailNotificacao(array $dadosChamado, array $interacoes) {
            try {
                $mail = $this->configurarEmail();

                switch ($dadosChamado['cha_status']) {
                    case 0:
                        $statusTexto = "NOVO";
                        break;
                    case 1:
                        $statusTexto = "PENDENTE SUPORTE";
                        break;
                    case 2:
                        $statusTexto = "PENDENTE CLIENTE";
                        break;
                    case 3:
                        $statusTexto = "FECHADO";
                        break;
                    default:
                        $statusTexto = "Desconhecido";
                        break;
                }
        
                // Configurações do e-mail
                $mail->setFrom('network-online@outlook.com.br', 'Network Online');
                $mail->addAddress($dadosChamado['cha_email'], $dadosChamado['cha_contato']);
                $mail->Subject = 'Seu chamado ['.$dadosChamado['cha_codigo'].'] recebeu uma atualização.';
                $mail->CharSet = 'UTF-8';
                $codigoHtml = "
                <!DOCTYPE html>
                <html xmlns:v=&quot;urn:schemas&ndash;microsoft&ndash;com:vml&quot;
                xmlns:o=&quot;urn:schemas&ndash;microsoft&ndash;com:office:office&quot;
                xmlns:w=&quot;urn:schemas&ndash;microsoft&ndash;com:office:word&quot;
                xmlns:m=&quot;http://schemas.microsoft.com/office/2004/12/omml&quot;
                xmlns=&quot;http://www.w3.org/TR/REC&ndash;html40&quot;>
                
                <head>
                <meta charset=\"UTF-8\">
                <meta http&ndash;equiv=Content&ndash;Type content=&quot;text/html; charset=unicode&quot;>
                <meta name=ProgId content=Word.Document>
                <meta name=Generator content=&quot;Microsoft Word 15&quot;>
                <meta name=Originator content=&quot;Microsoft Word 15&quot;>
                <link rel=File&ndash;List href=&quot;Template%20chamado_arquivos/filelist.xml&quot;>
                <link rel=Edit&ndash;Time&ndash;Data href=&quot;Template%20chamado_arquivos/editdata.mso&quot;>
                <link rel=themeData href=&quot;Template%20chamado_arquivos/themedata.thmx&quot;>
                <link rel=colorSchemeMapping
                href=&quot;Template%20chamado_arquivos/colorschememapping.xml&quot;>
                <style>
                    .linha-par {
                        background-color: #F2FBEF; /* Cor de fundo para linhas pares */
                    }

                    .linha-impar {
                        background-color: #FFFFFF; /* Cor de fundo para linhas ímpares */
                    }
                </style>

                </head>
                
                <body lang=PT&ndash;BR link=&quot;#467886&quot; vlink=&quot;#96607D&quot; style='tab&ndash;interval:35.4pt;
                word&ndash;wrap:break&ndash;word'>
                
                <div class=WordSection1>
                
                <div align=center>
                ##- Não escreva abaixo desta linha -##
                <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=826
                style='width:619.4pt;border&ndash;collapse:collapse;mso&ndash;yfti&ndash;tbllook:1184;
                mso&ndash;padding&ndash;alt:0cm 0cm 0cm 0cm'>
                <tr style='mso&ndash;yfti&ndash;irow:0;mso&ndash;yfti&ndash;firstrow:yes;mso&ndash;yfti&ndash;lastrow:yes;
                height:12.45pt'>
                <td width=826 style='width:619.4pt;border:solid white 1.0pt;mso&ndash;border&ndash;themecolor:
                background1;border&ndash;bottom:none;mso&ndash;border&ndash;top&ndash;alt:solid white .5pt;
                mso&ndash;border&ndash;top&ndash;themecolor:background1;mso&ndash;border&ndash;left&ndash;alt:solid white .5pt;
                mso&ndash;border&ndash;left&ndash;themecolor:background1;mso&ndash;border&ndash;right&ndash;alt:solid white .5pt;
                mso&ndash;border&ndash;right&ndash;themecolor:background1;padding:11.25pt 15.0pt 11.25pt 15.0pt;
                height:12.45pt'>
                <table class=MsoNormalTable border=1 cellspacing=0 cellpadding=0 align=left
                width=785 style='width:588.6pt;background:white;border&ndash;collapse:collapse;
                border:none;mso&ndash;border&ndash;alt:solid windowtext .5pt;mso&ndash;table&ndash;overlap:never;
                mso&ndash;yfti&ndash;tbllook:1184;mso&ndash;table&ndash;lspace:7.05pt;margin&ndash;left:4.8pt;mso&ndash;table&ndash;rspace:
                7.05pt;margin&ndash;right:4.8pt;mso&ndash;table&ndash;anchor&ndash;vertical:paragraph;mso&ndash;table&ndash;anchor&ndash;horizontal:
                margin;mso&ndash;table&ndash;left:left;mso&ndash;table&ndash;top:&ndash;10.35pt;mso&ndash;padding&ndash;alt:0cm 0cm 0cm 0cm;
                mso&ndash;border&ndash;insideh:.5pt solid windowtext;mso&ndash;border&ndash;insidev:.5pt solid windowtext'>
                <tr style='mso&ndash;yfti&ndash;irow:0;mso&ndash;yfti&ndash;firstrow:yes;mso&ndash;yfti&ndash;lastrow:yes;
                    height:121.9pt'>
                    <td width=&quot;100%&quot; style='width:100.0%;border:solid #BFBFBF 1.0pt;mso&ndash;border&ndash;themecolor:
                    background1;mso&ndash;border&ndash;themeshade:191;mso&ndash;border&ndash;alt:solid #BFBFBF .5pt;
                    mso&ndash;border&ndash;themecolor:background1;mso&ndash;border&ndash;themeshade:191;padding:27.0pt 27.0pt 27.0pt 27.0pt;
                    height:121.9pt'>
                    <table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0
                    align=left width=&quot;98%&quot; style='width:98.28%;border&ndash;collapse:collapse;
                    mso&ndash;table&ndash;overlap:never;mso&ndash;yfti&ndash;tbllook:1184;mso&ndash;table&ndash;lspace:7.05pt;
                    margin&ndash;left:4.8pt;mso&ndash;table&ndash;rspace:7.05pt;margin&ndash;right:4.8pt;mso&ndash;table&ndash;bspace:
                    3.5pt;margin&ndash;bottom:1.25pt;mso&ndash;table&ndash;anchor&ndash;vertical:paragraph;mso&ndash;table&ndash;anchor&ndash;horizontal:
                    margin;mso&ndash;table&ndash;left:left;mso&ndash;table&ndash;top:197.25pt;mso&ndash;padding&ndash;alt:0cm 0cm 0cm 0cm'>
                    <tr style='mso&ndash;yfti&ndash;irow:0;mso&ndash;yfti&ndash;firstrow:yes;height:15.6pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                    height:15.6pt'>
                    <p class=MsoNormal align=center style='text&ndash;align:center;mso&ndash;line&ndash;height&ndash;alt:
                    11.55pt'><b><span style='font&ndash;size:16.0pt;font&ndash;family:&quot;Segoe UI Semibold&quot;,sans&ndash;serif;
                    mso&ndash;fareast&ndash;font&ndash;family:&quot;Times New Roman&quot;;color:#3A3A3A;mso&ndash;themecolor:
                    background2;mso&ndash;themeshade:64;mso&ndash;style&ndash;textfill&ndash;fill&ndash;color:#3A3A3A;
                    mso&ndash;style&ndash;textfill&ndash;fill&ndash;themecolor:background2;mso&ndash;style&ndash;textfill&ndash;fill&ndash;alpha:
                    100.0%;mso&ndash;style&ndash;textfill&ndash;fill&ndash;colortransforms:lumm=25000;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>Nova atualiza&ccedil;&atilde;o em seu chamado</span></b><b><span
                    style='font&ndash;size:16.0pt;font&ndash;family:&quot;Segoe UI Semibold&quot;,sans&ndash;serif;
                    mso&ndash;fareast&ndash;font&ndash;family:&quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:
                    background1;mso&ndash;fareast&ndash;language:PT&ndash;BR'><o:p></o:p></span></b></p>
                    </td>
                    </tr>
                    <tr style='mso&ndash;yfti&ndash;irow:1;height:6.6pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;background:#654A9D;
                    padding:0cm 0cm 0cm 0cm;height:6.6pt'>
                    <p class=MsoNormal align=center style='text&ndash;align:center;mso&ndash;line&ndash;height&ndash;alt:
                    11.55pt'><b><span style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;
                    mso&ndash;fareast&ndash;font&ndash;family:&quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:
                    background1;mso&ndash;fareast&ndash;language:PT&ndash;BR'>CHAMADO N&deg;: " . $dadosChamado['cha_codigo'] . "</span></b><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;mso&ndash;fareast&ndash;language:PT&ndash;BR'><o:p></o:p></span></b></p>
                    </td>
                    </tr>
                    <tr style='mso&ndash;yfti&ndash;irow:2;height:6.6pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;background:#654A9D;
                    padding:0cm 0cm 0cm 0cm;height:6.6pt'>
                    <p class=MsoNormal style='mso&ndash;line&ndash;height&ndash;alt:11.55pt'><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'><span style='mso&ndash;spacerun:yes'>&nbsp;</span>Status:</span></b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>&nbsp;$statusTexto<o:p></o:p></span></p>
                    <p class=MsoNormal style='mso&ndash;line&ndash;height&ndash;alt:11.55pt'><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'><span style='mso&ndash;spacerun:yes'>&nbsp;</span>Abertura: </span></b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>" . date('d/m/Y H:i:s', strtotime($dadosChamado['cha_dataabertura'])) . "<o:p></o:p></span></p>
                    <p class=MsoNormal style='mso&ndash;line&ndash;height&ndash;alt:11.55pt'><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'><span style='mso&ndash;spacerun:yes'>&nbsp;</span>Assunto: </span></b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>" . $dadosChamado['cha_assunto'] . "<o:p></o:p></span></p>
                    <p class=MsoNormal style='mso&ndash;line&ndash;height&ndash;alt:11.55pt'><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'><span style='mso&ndash;spacerun:yes'>&nbsp;</span>Contato: </span></b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>" . $dadosChamado['cha_contato'] . "<o:p></o:p></span></p>
                    <p class=MsoNormal style='mso&ndash;line&ndash;height&ndash;alt:11.55pt'><b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'><span style='mso&ndash;spacerun:yes'>&nbsp;</span>Telefone: </span></b><span
                    style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;mso&ndash;fareast&ndash;font&ndash;family:
                    &quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:background1;mso&ndash;fareast&ndash;language:
                    PT&ndash;BR'>" . $dadosChamado['cha_telefone'] . "<b><o:p></o:p></b></span></p>
                    </td>
                    </tr>
                    <tr style='mso&ndash;yfti&ndash;irow:3;height:6.1pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                    height:6.1pt'>
                    <p class=MsoNormal align=center style='mso&ndash;margin&ndash;top&ndash;alt:auto;
                    mso&ndash;margin&ndash;bottom&ndash;alt:auto;text&ndash;align:center;line&ndash;height:105%'><b><span
                    style='font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;color:#747474;mso&ndash;themecolor:
                    background2;mso&ndash;themeshade:128;mso&ndash;style&ndash;textfill&ndash;fill&ndash;color:#747474;
                    mso&ndash;style&ndash;textfill&ndash;fill&ndash;themecolor:background2;mso&ndash;style&ndash;textfill&ndash;fill&ndash;alpha:
                    100.0%;mso&ndash;style&ndash;textfill&ndash;fill&ndash;colortransforms:lumm=50000'><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                    </tr>";

                    if($dadosChamado['cha_agendado'] == 1){
                        $codigoHtml .= "
                    <tr style='mso&ndash;yfti&ndash;irow:3;height:6.1pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                    height:6.1pt; background-color: #1ABC9C;'>
                    <p class=MsoNormal align=left style='mso&ndash;margin&ndash;top&ndash;alt:auto;
                    mso&ndash;margin&ndash;bottom&ndash;alt:auto;text&ndash;align:center;line&ndash;height:105%'><b><span
                    style='font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;color:#FFFFFF;mso&ndash;themecolor:
                    background2;mso&ndash;themeshade:128;mso&ndash;style&ndash;textfill&ndash;fill&ndash;color:#1ABC9C;
                    mso&ndash;style&ndash;textfill&ndash;fill&ndash;themecolor:background2;mso&ndash;style&ndash;textfill&ndash;fill&ndash;alpha:
                    100.0%;mso&ndash;style&ndash;textfill&ndash;fill&ndash;colortransforms:lumm=50000'><o:p>Chamado agendado para: " 
                    . date('d/m/Y H:i', strtotime($dadosChamado['cha_dataagendamento'])) . "<br/>Observações sobre o agendamento: " . $dadosChamado['cha_obsagendamento'] . "</o:p></span></b></p>
                    </td>
                    </tr>
                    <tr style='mso&ndash;yfti&ndash;irow:3;height:6.1pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                    height:6.1pt'>
                    <p class=MsoNormal align=center style='mso&ndash;margin&ndash;top&ndash;alt:auto;
                    mso&ndash;margin&ndash;bottom&ndash;alt:auto;text&ndash;align:center;line&ndash;height:105%'><b><span
                    style='font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;color:#747474;mso&ndash;themecolor:
                    background2;mso&ndash;themeshade:128;mso&ndash;style&ndash;textfill&ndash;fill&ndash;color:#747474;
                    mso&ndash;style&ndash;textfill&ndash;fill&ndash;themecolor:background2;mso&ndash;style&ndash;textfill&ndash;fill&ndash;alpha:
                    100.0%;mso&ndash;style&ndash;textfill&ndash;fill&ndash;colortransforms:lumm=50000'><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                    </tr>";
                    }
                    "<tr style='mso&ndash;yfti&ndash;irow:3;height:6.1pt'>
                    <td width=&quot;100%&quot; valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                    height:6.1pt'>
                    <p class=MsoNormal align=center style='mso&ndash;margin&ndash;top&ndash;alt:auto;
                    mso&ndash;margin&ndash;bottom&ndash;alt:auto;text&ndash;align:center;line&ndash;height:105%'><b><span
                    style='font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;color:#747474;mso&ndash;themecolor:
                    background2;mso&ndash;themeshade:128;mso&ndash;style&ndash;textfill&ndash;fill&ndash;color:#747474;
                    mso&ndash;style&ndash;textfill&ndash;fill&ndash;themecolor:background2;mso&ndash;style&ndash;textfill&ndash;fill&ndash;alpha:
                    100.0%;mso&ndash;style&ndash;textfill&ndash;fill&ndash;colortransforms:lumm=50000'><o:p>&nbsp;</o:p></span></b></p>
                    </td>
                    </tr>";
        
                    if($interacoes){
                        $codigoHtml .= "<tr style='mso&ndash;yfti&ndash;irow:4;height:7.7pt'>
                        <td width=&quot;100%&quot; valign=top style='width:100.0%;background:#654A9D;
                        padding:0cm 0cm 0cm 0cm;height:7.7pt'>
                        <p class=MsoNormal align=center style='text&ndash;align:center;mso&ndash;line&ndash;height&ndash;alt:
                        11.55pt'><b><span style='font&ndash;size:12.0pt;font&ndash;family:&quot;Segoe UI&quot;,sans&ndash;serif;
                        mso&ndash;fareast&ndash;font&ndash;family:&quot;Times New Roman&quot;;color:white;mso&ndash;themecolor:
                        background1;mso&ndash;fareast&ndash;language:PT&ndash;BR'>INTERA&Ccedil;&Otilde;ES<o:p></o:p></span></b></p>
                        </td>
                        </tr>";
                    }
                $contador = 0;

                foreach ($interacoes as $interacao) {
                    $contador++;

                    // Defina uma classe alternada com base no contador
                    $classe = ($contador % 2 == 0) ? 'linha-par' : 'linha-impar';

                    $mensagem = $interacao['chi_comentario'];
                    $usuario = $interacao['chi_autor'];
                    $data_interacao = date('d/m/Y H:i:s', strtotime($interacao['chi_data']));

                    $codigoHtml .= "

                        <tr class='{$classe}' style='mso-yfti-irow:5;height:11.6pt'>
                            <td width=\"100%\" valign=top style='width:100.0%;padding:0cm 0cm 0cm 0cm;
                            height:11.6pt'>
                            <p class=MsoNormal style='mso-margin-top-alt:auto;mso-margin-bottom-alt:
                            auto;line-height:105%'><b><span style='font-size:10.0pt;line-height:105%;
                            font-family:\"Segoe UI\",sans-serif;color:#654A9D'>{$data_interacao} &ndash; {$usuario}</span></b><b><span
                            style='font-size:10.0pt;line-height:105%;font-family:\"Segoe UI\",sans-serif'>:</span></b><span style='font-family:\"Segoe UI\",sans-serif'> {$mensagem}<b> </b></span><b><span
                            style='font-size:10.0pt;line-height:105%;font-family:\"Segoe UI\",sans-serif;
                            color:#404040'><o:p></o:p></span></b></p>
                            </td>
                        </tr>
                    ";
                }
        
                $codigoHtml .= "
                    </div>
                </body>
                </html>
                ";
                $mail->Body = $codigoHtml;
                $mail->isHTML(true);
                $mail->send();
            } catch (Exception $e) {
                return "Erro no envio do e-mail: " . $e->getMessage();
            }

            return true;
        }
        
        public function getInteracoesChamado($cha_codigo) {
            try {
                $this->conn = $this->conectar();

                $query_interacoes = "SELECT * FROM tb_chamados_interacao WHERE cha_codigo = :cha_codigo  ORDER BY chi_data DESC";

                $stmt = $this->conn->prepare($query_interacoes);
                $stmt->bindParam(':cha_codigo', $cha_codigo, PDO::PARAM_INT);
                $stmt->execute();
                $num_rows = $stmt->rowCount();

                $interacoes = [];

                if ($num_rows > 0) {
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        $mensagem = $row['chi_comentario'];
                        $usuario = $row['chi_autor'];
                        $tipointeracao = $row['chi_interacaointerna'];

                        $data_interacao = date('d/m/Y H:i:s', strtotime($row['chi_data'])); // Formatação da data

                        $interacao = [
                            'tipo' => $tipointeracao,
                            'data' => $data_interacao,
                            'mensagem' => $mensagem,
                            'usuario' => $usuario,
                        ];

                        $interacoes[] = $interacao;
                    }
                }

                return $interacoes;
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }

        public function renderizarTabelaChamado($chamados, $currentPage = 1, $itemsPerPage = 11) {
            $html = '';
            $html .= '<script src="https://kit.fontawesome.com/6bef072b61.js" crossorigin="anonymous"></script>';
            $html .= '<table>';
            $html .= '<thead>';
            $html .= '<tr>';
            $html .= '<th>Código <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Cliente <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Assunto <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Contato <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>E-mail <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Telefone <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Técnico <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Status <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Data de abertura <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Deletar</th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';
    
            $totalChamados = count($chamados);
            $totalPages = ceil($totalChamados / $itemsPerPage);
    
            $startIndex = ($currentPage - 1) * $itemsPerPage;
            $endIndex = min($startIndex + $itemsPerPage - 1, $totalChamados - 1);
    
            for ($i = $startIndex; $i <= $endIndex; $i++) {
                $row_chamado_pg = $chamados[$i];
                extract($row_chamado_pg);
    
                switch ($cha_status) {
                    case 0:
                        $status_texto = 'NOVO';
                        break;
                    case 1:
                        $status_texto = 'PENDENTE SUPORTE';
                        break;
                    case 2:
                        $status_texto = 'PENDENTE CLIENTE';
                        break;
                    case 3:
                        $status_texto = 'FECHADO';
                        break;
                    default:
                        $status_texto = 'Desconhecido';
                }
    
                $consultaCliente = "SELECT pes_fantasia FROM tb_cliente WHERE pes_codigo = $pes_codigo";
                $resultadoConsulta = $this->conn->prepare($consultaCliente);
    
                if ($resultadoConsulta !== false) {
                    $resultadoConsulta->execute();
                    $cliente = $resultadoConsulta->fetch(PDO::FETCH_ASSOC); // Obtém os resultados
                    $pes_fantasia = $cliente['pes_fantasia'];
                } else {
                    $pes_fantasia = 'Cliente não encontrado';
                }
    
                $consultaTecnico = "SELECT usu_nome FROM tb_usuario WHERE usu_codigo = $usu_codigo";
                $resultadoConsulta = $this->conn->prepare($consultaTecnico);
    
                if ($resultadoConsulta !== false) {
                    $resultadoConsulta->execute(); // Executa a consulta
                    $tecnico = $resultadoConsulta->fetch(PDO::FETCH_ASSOC); // Obtém os resultados
                    $usu_nome = isset($tecnico['usu_nome']) ? $tecnico['usu_nome'] : 'Técnico não encontrado';
                } else {
                    $usu_nome = 'Tecnico não encontrado';
                }
    
                $dataFormatada = date("d/m/Y", strtotime($cha_dataabertura)); // Formata a data para dd/mm/yyyy
                $html .= '<tr class="chamado-row" data-id="' . $cha_codigo . '">';
                $html .= '<td>' . $cha_codigo . '</td>';
                $html .= '<td>' . $pes_fantasia . '</td>';
                $html .= '<td>' . $cha_assunto . '</td>';
                $html .= '<td>' . $cha_contato . '</td>';
                $html .= '<td>' . $cha_email . '</td>';
                $html .= '<td>' . $cha_telefone . '</td>';
                $html .= '<td>' . $usu_nome . '</td>';
                $html .= '<td>' . $status_texto . '</td>';
                $html .= '<td>' . $dataFormatada . '</td>';
                $html .= '<td><button class="button-deletar" data-id="' . $cha_codigo . '">
                <i class="fa-regular fa-trash-can" style="color: #6768ab;"></i></button></td>';
                $html .= '</tr>';
            }
    
            $html .= '</tbody>';
            $html .= '</table>';
            $html .= '<div class="pagination">';
    
            // Botão de retrocesso
            if ($currentPage > 1) {
                $prevPage = $currentPage - 1;
                $html .= '<a href="?page=' . $prevPage . '" class="page-link"><span class="page-number">&lt;</span></a>';
            }
    
            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i == $currentPage) {
                    // Página atual - destaque com círculo
                    $html .= '<span class="current-page-circle">' . $i . '</span>';
                } else {
                    // Página não atual - link normal
                    $html .= '<a href="?page=' . $i . '" class="page-link"><span class="page-number">' . $i . '</span></a>';
                }
            }
    
            // Botão de avanço
            if ($currentPage < $totalPages) {
                $nextPage = $currentPage + 1;
                $html .= '<a href="?page=' . $nextPage . '" class="page-link"><span class="page-number">&gt;</span></a>';
            }
    
            $html .= '<form action="" method="get" class="page-form">';
            $html .= '<input class="page-input" type="number" name="page" id="page" min="1" max="' . $totalPages . '" value="' . $currentPage . '" />';
            $html .= '</form>';
    
            $html .= '<script>';
            $html .= 'document.getElementById("page").addEventListener("input", function() {';
            $html .= '  var inputValue = this.value.trim();';
            $html .= '  if (inputValue !== "" && !isNaN(inputValue) && inputValue >= 1 && inputValue <= ' . $totalPages . ') {';
            $html .= '    window.location.href = "?page=" + inputValue;';
            $html .= '  }';
            $html .= '});';
            $html .= '</div>';
            $html .= '</script>';
    
            return $html;
        }
        
        /////INDICADORES/////
        public function getMeses() {
            $meses = [];
            $calendario = new Calendario();
        
            for ($i = 1; $i <= 12; $i++) {
                $meses[] = [
                    'valor' => $i,
                    'nome' => $calendario->getNomeMes($i),
                ];
            }
            return $meses;
        }        
    
        public function getAnos() {
            $anos = [];
            $anoAtual = date('Y');
            for ($i = $anoAtual; $i >= $anoAtual - 10; $i--) {
                $anos[] = [
                    'valor' => $i,
                    'selecionado' => ($i == $anoAtual) ? 'selected' : '',
                ];
            }
            return $anos;
        }

         public function getAvailableYears($selectedYear2) {
        $currentYear = date('Y');
        $years = [];

        for ($i = $currentYear; $i >= $currentYear - 10; $i--) {
            $selected = ($i == $selectedYear2) ? 'selected' : '';
            $years[] = ['value' => $i, 'selected' => $selected];
        }

        return $years;
    }
        public function getChartData($year) {
            try {
                require_once('app/models/Grafico.php'); 
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT DATE_FORMAT(cha_dataabertura, '%M') as monthname, COUNT(*) as amount 
                                    FROM tb_chamados 
                                    WHERE YEAR(cha_dataabertura) = :year
                                    GROUP BY MONTH(cha_dataabertura)";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetchAll();
    
                $chartData = new ChartData($data);
    
                return [
                    'labels' => $chartData->getMonthData(),
                    'amount' => $chartData->getAmountData(),
                ];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    
        public function getTotalChamados($year, $month) {
            try {
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT COUNT(*) AS total_chamados 
                                    FROM tb_chamados 
                                    WHERE YEAR(cha_dataabertura) = :year AND MONTH(cha_dataabertura) = :month";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->bindParam(':month', $month, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetch(PDO::FETCH_ASSOC);
    
                return $data['total_chamados'];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    
        public function getChamadosAbertos($year, $month) {
            try {
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT COUNT(*) AS chamados_abertos FROM tb_chamados 
                                    WHERE cha_status <> 3 and YEAR(cha_dataabertura) = :year AND MONTH(cha_dataabertura) = :month";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->bindParam(':month', $month, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetch(PDO::FETCH_ASSOC);
    
                return $data['chamados_abertos'];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    
        public function getChamadosAndamento($year, $month) {
            try {
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT COUNT(*) AS chamados_andamento FROM tb_chamados 
                                    WHERE cha_status <> 3 and cha_status <> 0 and YEAR(cha_dataabertura) = :year AND MONTH(cha_dataabertura) = :month";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->bindParam(':month', $month, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetch(PDO::FETCH_ASSOC);
    
                return $data['chamados_andamento'];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    
        public function getChamadosFechados($year, $month) {
            try {
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT COUNT(*) AS chamados_fechados FROM tb_chamados 
                                    WHERE cha_status = 3 and YEAR(cha_dataabertura) = :year AND MONTH(cha_dataabertura) = :month";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->bindParam(':month', $month, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetch(PDO::FETCH_ASSOC);
    
                return $data['chamados_fechados'];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    
        public function getChamadosAgendados($year, $month) {
            try {
                $this->conn = $this->conectar();
    
                $query_chamados = "SELECT COUNT(*) AS total_agendados FROM tb_chamados 
                                    WHERE cha_dataagendamento <> '0000-00-00 00:00:00' and YEAR(cha_dataabertura) = :year AND MONTH(cha_dataabertura) = :month";
    
                $result = $this->conn->prepare($query_chamados);
                $result->bindParam(':year', $year, PDO::PARAM_INT);
                $result->bindParam(':month', $month, PDO::PARAM_INT);
                $result->execute();
                $data = $result->fetch(PDO::FETCH_ASSOC);
    
                return $data['total_agendados'];
            } catch (PDOException $e) {
                // Exiba mensagens de erro para depuração
                echo "Erro no banco de dados: " . $e->getMessage();
                return false;
            }
        }
    }