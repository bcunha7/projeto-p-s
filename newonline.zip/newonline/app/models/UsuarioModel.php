<?php
require_once 'app/models/Conexao.php';
    class UsuarioModel extends Conexao
    {
        private array $formDados;
        private int $formCodigo; 
        private object $conn;

        public function setFormDados(array $formDados): void {
            $this->formDados = $formDados;
        }
        public function setFormCodigo(int $formCodigo): void {
            $this->formCodigo = $formCodigo;
        }
        public function cadastrarUsuario(): bool {
            require_once 'app/controllers/PaginaController.php';
            $this->conn = $this->conectar();
            $query_usuario = "INSERT INTO tb_usuario (usu_nome, usu_email, usu_senha) VALUES (:usu_nome, :usu_email, :usu_senha)";
            $cad_usuario = $this->conn->prepare($query_usuario);
    
            $cad_usuario->bindParam(':usu_nome', $this->formDados['usu_nome']);
            $cad_usuario->bindParam(':usu_email', $this->formDados['usu_email']);
            $cad_usuario->bindParam(':usu_senha', $this->formDados['usu_senha']);
    
            $cad_usuario->execute();
    
            if ($cad_usuario->rowCount()) {
                // Obtém o ID do usuário recém-cadastrado
                $usu_codigo = $this->conn->lastInsertId();
    
                // Instancia a classe que contém a função cadastrarPermissaoPaginas e chama a função
                $permissaoHandler = new PaginaController();
                $permissaoHandler->cadastrarPermissao($usu_codigo);
    
                return true;
            } else {
                return false;
            }
        }
    
        public function editarUsuario($usu_codigo): bool {
            $this->conn = $this->conectar();
            $query_usuario = "UPDATE tb_usuario
                            SET usu_nome = :usu_nome, usu_email = :usu_email, usu_senha = :usu_senha
                            WHERE usu_codigo = :usu_codigo";
            $editar_usuario = $this->conn->prepare($query_usuario);
        
            $editar_usuario->bindParam(':usu_nome', $this->formDados['usu_nome']);
            $editar_usuario->bindParam(':usu_email', $this->formDados['usu_email']);
            $editar_usuario->bindParam(':usu_senha', $this->formDados['usu_senha']);
            $editar_usuario->bindParam(':usu_codigo', $usu_codigo); // Adicione esta linha
        
            $editar_usuario->execute();
            
            if($editar_usuario->rowCount()){
                return true;
            } else {
                return false;
            }
        }
        public function excluirUsuario($usu_codigo): bool {
            $this->conn = $this->conectar();
        
            $query_usuario = "DELETE FROM tb_usuario WHERE usu_codigo = :usu_codigo";
        
            $excluir_usuario = $this->conn->prepare($query_usuario);
            $excluir_usuario->bindParam(':usu_codigo', $usu_codigo, PDO::PARAM_INT);
            $excluir_usuario->execute();
        
            return $excluir_usuario->rowCount() > 0;
        }

        public function buscarUsuarioPorCod($usu_codigo): array {
            $this->conn = $this->conectar();
        
            $query_usuario = "SELECT * FROM tb_usuario WHERE usu_codigo = :usu_codigo";
        
            $buscar_usuario = $this->conn->prepare($query_usuario);
            $buscar_usuario->bindParam(':usu_codigo', $usu_codigo, PDO::PARAM_INT);
            $buscar_usuario->execute();
            $usuario = $buscar_usuario->fetch(PDO::FETCH_ASSOC);
        
            return $usuario;
        }

        public function listarUsuario(): array {
            $this->conn = $this->conectar();
            $query_usuario = "SELECT usu_codigo, usu_nome, usu_email, usu_senha
                    FROM tb_usuario
                    ORDER BY usu_codigo DESC";
            $result_usuario = $this->conn->prepare($query_usuario);
            $result_usuario->execute();
            $retorno = $result_usuario->fetchAll();

            return $retorno;
        }

        public function opcoesTecnicos(): array {
            $opcoes = [];
            $list_usuario_pgs = $this->listarUsuario();
        
            foreach ($list_usuario_pgs as $usuario) {
                $opcoes[] = [
                    'value' => $usuario['usu_codigo'],
                    'label' => $usuario['usu_nome'],
                ];
            }
            return $opcoes;
        }

        public function pesquisarUsuario($pesquisar): array {
        
            $this->conn = $this->conectar();
            $query_usuario = "SELECT *
                    FROM tb_usuario
                    WHERE usu_nome LIKE :pesquisar";
            $result_usuario = $this->conn->prepare($query_usuario);
            $result_usuario->bindValue(':pesquisar', '%' . $pesquisar . '%', PDO::PARAM_STR);
            $result_usuario->execute();
            $retorno = $result_usuario->fetchAll();
            return $retorno;
        }
        public function excluirPermissaoPaginasPorUsuario($usu_codigo): bool {
            $this->conn = $this->conectar();

            $query_usuario = "DELETE FROM tb_paginas_usuario WHERE usu_codigo = :usu_codigo";

            $excluir_usuario = $this->conn->prepare($query_usuario);
            $excluir_usuario->bindParam(':usu_codigo', $usu_codigo, PDO::PARAM_INT);
            $excluir_usuario->execute();

            return $excluir_usuario->rowCount() > 0;
        }

        public function autenticarUsuario($usu_nome, $usu_senha) {
            $this->conn = $this->conectar();

            $query_autenticacao = "SELECT usu_codigo FROM tb_usuario WHERE usu_nome = :usu_nome AND usu_senha = :usu_senha";

            $autenticar_usuario = $this->conn->prepare($query_autenticacao);
            $autenticar_usuario->bindParam(':usu_nome', $usu_nome, PDO::PARAM_STR);
            $autenticar_usuario->bindParam(':usu_senha', $usu_senha, PDO::PARAM_STR);
            $autenticar_usuario->execute();

            if ($autenticar_usuario->rowCount() > 0) {
                // Autenticação bem-sucedida, obtenha informações do usuário
                $dados_usuario = $autenticar_usuario->fetch(PDO::FETCH_ASSOC);

                // Retorne o código do usuário
                return $dados_usuario['usu_codigo'];
            }

            return false;
        }
        public function renderizarTabelaUsuario($usuarios, $currentPage = 1, $itemsPerPage = 11) {
            $html = '<script src="https://kit.fontawesome.com/6bef072b61.js" crossorigin="anonymous"></script>';
            $html = '<table class="table">';
            $html .= '<thead>';
            $html .= '<tr>';
            $html .= '<th>Código</th>';
            $html .= '<th>Nome de usuário</th>';
            $html .= '<th>E-mail</th>';
            $html .= '<th>Deletar</th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';
            $totalUsuarios = count($usuarios);
            $totalPages = ceil($totalUsuarios / $itemsPerPage);

            // Calcula o índice inicial e final dos chamados a serem exibidos
            $startIndex = ($currentPage - 1) * $itemsPerPage;
            $endIndex = min($startIndex + $itemsPerPage - 1, $totalUsuarios - 1);

            for ($i = $startIndex; $i <= $endIndex; $i++) {
                $row_usuario_pg = $usuarios[$i]; 
                extract($row_usuario_pg);

                $html .= '<tr class="usuario-row" data-id="' . $usu_codigo . '">';
                $html .= '<td>' . $usu_codigo . '</td>';
                $html .= '<td>' . $usu_nome . '</td>';
                $html .= '<td>' . $usu_email . '</td>';
                $html .= '<td><button class="button-deletar" data-id="' . $usu_codigo . '">
                <i class="fa-regular fa-trash-can" style="color: #6768ab;"></i></button></td>';
                $html .= '</tr>';
            }

            $html .= '</tbody>';
            $html .= '</table>';
            $html .= '<div class="pagination">';

            // Botão de retrocesso
            if ($currentPage > 1) {
                $prevPage = $currentPage - 1;
                $html .= '<a href="?page=' . $prevPage . '" class="page-link"><span class="page-number">&lt;</span></a>';
            }

            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i == $currentPage) {
                    // Página atual - destaque com círculo
                    $html .= '<span class="current-page-circle">' . $i . '</span>';
                } else {
                    // Página não atual - link normal
                    $html .= '<a href="?page=' . $i . '" class="page-link"><span class="page-number">' . $i . '</span></a>';
                }
            }

            // Botão de avanço
            if ($currentPage < $totalPages) {
                $nextPage = $currentPage + 1;
                $html .= '<a href="?page=' . $nextPage . '" class="page-link"><span class="page-number">&gt;</span></a>';
            }

            $html .= '<form action="" method="get" class="page-form">';
            $html .= '<input class="page-input" type="number" name="page" id="page" min="1" max="' . $totalPages . '" value="' . $currentPage . '" />';
            $html .= '</form>';

            $html .= '<script>';
            $html .= 'document.getElementById("page").addEventListener("input", function() {';
            $html .= '  var inputValue = this.value.trim();';
            $html .= '  if (inputValue !== "" && !isNaN(inputValue) && inputValue >= 1 && inputValue <= ' . $totalPages . ') {';
            $html .= '    window.location.href = "?page=" + inputValue;';
            $html .= '  }';
            $html .= '});';
            $html .= '</script>';
            
            $html .= '</div>';
            return $html;
        }
    }