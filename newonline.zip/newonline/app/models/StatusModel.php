<?php

class StatusModel {
    public function getStatusOptions() {
        return array(
            0 => "NOVO",
            1 => "PENDENTE SUPORTE",
            2 => "PENDENTE CLIENTE",
            3 => "FECHADO"
        );
    }
}

