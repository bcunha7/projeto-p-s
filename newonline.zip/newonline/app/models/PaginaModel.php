<?php

require_once 'app/models/Conexao.php';
if (!class_exists('PaginaModel')) {
    class PaginaModel extends Conexao
    {
        private array $formDados;
        private int $formCodigo; 
        private object $conn;

        public function setFormDados(array $formDados): void {
            $this->formDados = $formDados;
        }

        public function setFormCodigo(int $formCodigo): void {
            $this->formCodigo = $formCodigo;
        }
        public function consultarPermissoes($usu_codigo) {
            $this->conn = $this->conectar();
        
            $query = "SELECT p.pag_nome
                      FROM tb_paginas_usuario pu
                      JOIN tb_paginas p ON pu.pag_codigo = p.pag_codigo
                      WHERE pu.usu_codigo = :usu_codigo AND pu.permitir = 1";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':usu_codigo', $usu_codigo);
            $stmt->execute();
        
        
            if (!$stmt) {
                echo "Erro na preparação da consulta.";
                exit;
            }
        
            $paginasUsuario = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
            $nomesPaginas = array_column($paginasUsuario, 'pag_nome');
            return $nomesPaginas;
        }
        
        public function cadastrarPermissaoPaginas($usu_codigo): bool {
            $this->conn = $this->conectar();
    
            // Obtém todos os códigos de página da tabela tb_paginas
            $query_paginas = "SELECT pag_codigo FROM tb_paginas";
            $stmt_paginas = $this->conn->prepare($query_paginas);
            $stmt_paginas->execute();
    
            // Prepara a query de inserção nas permissões
            $query_permissao = "INSERT INTO tb_paginas_usuario (pag_codigo, usu_codigo, permitir) VALUES (:pag_codigo, :usu_codigo, false)";
            $cad_permissao = $this->conn->prepare($query_permissao);
            $cad_permissao->bindParam(':usu_codigo', $usu_codigo);
    
            // Itera sobre os resultados da query de códigos de página
            while ($row = $stmt_paginas->fetch(PDO::FETCH_ASSOC)) {
                $pag_codigo = $row['pag_codigo'];
    
                // Associa o código da página à variável na query de permissão e executa
                $cad_permissao->bindParam(':pag_codigo', $pag_codigo);
                $cad_permissao->execute();
            }
    
            // Verifica se pelo menos uma permissão foi cadastrada
            if ($cad_permissao->rowCount()) {
                return true;
            } else {
                return false;
            }
        }
        public function consultarPermissaoPaginas() {
            $this->conn = $this->conectar();
            $query = "SELECT * FROM tb_paginas_usuario";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        public function consultarNomePagina($pag_codigo) {
            $query = "SELECT pag_nome FROM tb_paginas WHERE pag_codigo = :pag_codigo";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':pag_codigo', $pag_codigo);
            $stmt->execute();
        
            // Fetch all page names into an array
            $nomesPaginas = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
            // Modificação: Retorna o array de nomes de páginas
            return $nomesPaginas;
        }
        
        public function editarPermissao($pag_codigo, $usu_codigo, $permitir): bool {
            $this->conn = $this->conectar();
            $query_permissao = "UPDATE tb_paginas_usuario
                            SET permitir = :permitir
                            WHERE pag_codigo = :pag_codigo AND usu_codigo = :usu_codigo";
            $editar_permissao = $this->conn->prepare($query_permissao);
        
            $editar_permissao->bindParam(':permitir', $permitir);
            $editar_permissao->bindParam(':pag_codigo', $pag_codigo);
            $editar_permissao->bindParam(':usu_codigo', $usu_codigo);
        
            $editar_permissao->execute();
        
            if($editar_permissao->rowCount()){
                return true;
            } else {
                return false;
            }
        }
        
        public function consultarPermissaoPaginasPorUsuario($usu_codigo) {
            $this->conn = $this->conectar();
        
            // Modifique a consulta para filtrar as páginas do usuário
            $query = "SELECT * FROM tb_paginas_usuario WHERE usu_codigo = :usu_codigo";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':usu_codigo', $usu_codigo);
            $stmt->execute();
            
            // Verificação do objeto $stmt antes de continuar
            if (!$stmt) {
                echo "Erro na preparação da consulta.";
                var_dump($this->conn->errorInfo());
                exit;
            }
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        public function obterPaginas() {
            $this->conn = $this->conectar();
        
            // Modifique a consulta para filtrar as páginas do usuário
            $query = "SELECT * FROM tb_paginas";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            // Verificação do objeto $stmt antes de continuar
            if (!$stmt) {
                echo "Erro na preparação da consulta.";
                var_dump($this->conn->errorInfo());
                exit;
            }
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        // No arquivo Pagina.php
        function temPermissao($pagina, $permissoesUsuario) {

            return in_array($pagina, $permissoesUsuario);
        }
        
        public function renderizarTabelaPermitir($permissoes, $currentPage = 1, $itemsPerPage = 11) {
            $html = '<script src="https://kit.fontawesome.com/6bef072b61.js" crossorigin="anonymous"></script>';

            $html .= '<table>';
            $html .= '<thead>';
            $html .= '<tr>';
            $html .= '<th>Código <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Páginas <i class="fa-solid fa-sort" style="color: #ffffff;"></i></th>';
            $html .= '<th>Permissão</th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';
        
            $totalPermissoes = count($permissoes);
            $totalPages = ceil($totalPermissoes / $itemsPerPage);

            // Calcula o índice inicial e final dos chamados a serem exibidos
            $startIndex = ($currentPage - 1) * $itemsPerPage;
            $endIndex = min($startIndex + $itemsPerPage - 1, $totalPermissoes - 1);

            for ($i = $startIndex; $i <= $endIndex; $i++) {
                $row_permissao_pg = $permissoes[$i]; 
                extract($row_permissao_pg);

                $nomes_pagina = $this->consultarNomePagina($pag_codigo);
                $nome_pagina = implode(', ', $nomes_pagina); // Transforma o array em uma string
                
                $html .= '<tr class="permissao-row" data-id="' . $pag_codigo . '">';
                $html .= '<td>' . $pag_codigo . '</td>';       
                $html .= '<td>' . $nome_pagina . '</td>';
                $html .= '<td><input type="checkbox" name="permissoes[]" value="' . $permitir . '" id="checkbox_' . $pag_codigo . '" data-usu-codigo="' . $usu_codigo . '" ' . ($permitir ? 'checked' : '') . ' onclick="confirmarAtualizacaoPermissao(' . $pag_codigo . ')"></td>';
                $html .= '</tr>';
                
            }       
            $html .= '</tbody>';
            $html .= '</table>';
            $html .= '<div class="pagination">';

            // Botão de retrocesso
            if ($currentPage > 1) {
                $prevPage = $currentPage - 1;
                $html .= '<a href="?page=' . $prevPage . '" class="page-link"><span class="page-number">&lt;</span></a>';
            }
            
            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i == $currentPage) {
                    // Página atual - destaque com círculo
                    $html .= '<span class="current-page-circle">' . $i . '</span>';
                } else {
                    // Página não atual - link normal
                    $html .= '<a href="?page=' . $i . '" class="page-link"><span class="page-number">' . $i . '</span></a>';
                }
            }
            if ($currentPage < $totalPages) {
                $nextPage = $currentPage + 1;
                $html .= '<a href="?page=' . $nextPage . '" class="page-link"><span class="page-number">&gt;</span></a>';
            }
            
            $html .= '<form action="" method="get" class="page-form">';
            $html .= '<input class="page-input" type="number" name="page" id="page" min="1" max="' . $totalPages . '" value="' . $currentPage . '" />';
            $html .= '</form>';                       
            $html .= '</div>';
        
            return $html;
        }        
    }
}