<?php
require_once 'app/models/Conexao.php';
    class ClienteModel extends Conexao
    {
        private array $formDados;
        private int $formCodigo; 
        private object $conn;

        public function setFormDados(array $formDados): void {
            $this->formDados = $formDados;
        }
        public function setFormCodigo(int $formCodigo): void {
            $this->formCodigo = $formCodigo;
        }
        public function cadastrarCliente(): bool {
            //var_dump($this->formDados);
            $this->conn = $this->conectar();
            $query_cliente = "INSERT INTO tb_cliente
                    (pes_fantasia, pes_razao, pes_cpfcnpj, pes_datacadastro, pes_tipopessoa, pes_observacao, pes_ativo)
                    VALUES (:pes_fantasia, :pes_razao, :pes_cpfcnpj, NOW(), :pes_tipopessoa, :pes_observacao, 's')";
            $cad_cliente = $this->conn->prepare($query_cliente);
            
            $cad_cliente->bindParam(':pes_fantasia', $this->formDados['pes_fantasia']);
            $cad_cliente->bindParam(':pes_razao', $this->formDados['pes_razao']);
            $cad_cliente->bindParam(':pes_cpfcnpj', $this->formDados['pes_cpfcnpj']);
            $cad_cliente->bindParam(':pes_tipopessoa', $this->formDados['pes_tipopessoa']);
            $cad_cliente->bindParam(':pes_observacao', $this->formDados['pes_observacao']);
    
            $cad_cliente->execute();
            if($cad_cliente->rowCount()){
                return true;
            }else{
                return false;
            }
        }

        public function editarCliente($pes_codigo): bool {
            $this->conn = $this->conectar();
            $query_cliente = "UPDATE tb_cliente
                            SET pes_fantasia = :pes_fantasia, pes_razao = :pes_razao, pes_cpfcnpj = :pes_cpfcnpj, pes_tipopessoa = :pes_tipopessoa, pes_observacao = :pes_observacao
                            WHERE pes_codigo = :pes_codigo";
            $editar_cliente = $this->conn->prepare($query_cliente);

            $editar_cliente->bindParam(':pes_fantasia', $this->formDados['pes_fantasia']);
            $editar_cliente->bindParam(':pes_razao', $this->formDados['pes_razao']);
            $editar_cliente->bindParam(':pes_cpfcnpj', $this->formDados['pes_cpfcnpj']);
            $editar_cliente->bindParam(':pes_tipopessoa', $this->formDados['pes_tipopessoa']);
            $editar_cliente->bindParam(':pes_observacao', $this->formDados['pes_observacao']);
            
            // Adicione a linha abaixo para vincular :pes_codigo
            $editar_cliente->bindParam(':pes_codigo', $pes_codigo);

            $editar_cliente->execute();
            
            if($editar_cliente->rowCount()){
                return true;
            } else {
                return false;
            }
        }

        public function excluirCliente($pes_codigo): bool {
            $this->conn = $this->conectar();

            $query_cliente = "DELETE FROM tb_cliente WHERE pes_codigo = :pes_codigo";

            $excluir_cliente = $this->conn->prepare($query_cliente);
            $excluir_cliente->bindParam(':pes_codigo', $pes_codigo, PDO::PARAM_INT);
            $excluir_cliente->execute();

            return $excluir_cliente->rowCount() > 0;
        }

        public function buscarClientePorCod($pes_codigo): array {
            $this->conn = $this->conectar();
            $query_cliente = "SELECT * FROM tb_cliente WHERE pes_codigo = :pes_codigo";

            $buscar_cliente = $this->conn->prepare($query_cliente);
            $buscar_cliente ->bindParam(':pes_codigo', $pes_codigo, PDO::PARAM_INT);
            $buscar_cliente ->execute();
            $cliente = $buscar_cliente->fetch(PDO::FETCH_ASSOC);

            return $cliente;
        }
        public function pesquisarCliente($pesquisar): array {
        
            $this->conn = $this->conectar();
            $query_cliente = "SELECT *
                    FROM tb_cliente
                    WHERE pes_fantasia LIKE :pesquisar";
            $result_cliente = $this->conn->prepare($query_cliente);
            $result_cliente ->bindValue(':pesquisar', '%' . $pesquisar . '%', PDO::PARAM_STR);
            $result_cliente ->execute();
            $retorno = $result_cliente ->fetchAll();
            return $retorno;
        }

        public function listarCliente(): array {
            $this->conn = $this->conectar();
            $query_cliente = "SELECT pes_codigo, pes_fantasia, pes_razao, pes_cpfcnpj, pes_datacadastro, pes_tipopessoa, pes_observacao
                    FROM tb_cliente
                    ORDER BY pes_codigo DESC";
            $result_cliente = $this->conn->prepare($query_cliente);
            $result_cliente->execute();
            $retorno = $result_cliente->fetchAll();
            return $retorno;
        }

        public function opcoesClientes(): array {
            $opcoes = [];
            $list_cliente_pgs = $this->listarCliente();

            foreach ($list_cliente_pgs as $cliente) {
                $opcoes[] = [
                    'value' => $cliente['pes_codigo'],
                    'label' => $cliente['pes_fantasia'],
                ];
            }

            return $opcoes;
        }

        public function renderizarTabelaCliente($clientes, $currentPage = 1, $itemsPerPage = 11) {
            $html = '<script src="https://kit.fontawesome.com/6bef072b61.js" crossorigin="anonymous"></script>';
            $html = '<table class="table">';
            $html .= '<thead>';
            $html .= '<tr>';
            $html .= '<th>Código</th>';
            $html .= '<th>Nome fantasia</th>';
            $html .= '<th>Razão social</th>';
            $html .= '<th>CPF/CNPJ</th>';
            $html .= '<th>Data de cadastro</th>';
            $html .= '<th>Tipo pessoa</th>';
            $html .= '<th>Observações</th>';
            $html .= '<th>Deletar </th>';
            $html .= '</tr>';
            $html .= '</thead>';
            $html .= '<tbody>';

            $totalClientes = count($clientes);
            $totalPages = ceil($totalClientes / $itemsPerPage);

            // Calcula o índice inicial e final dos chamados a serem exibidos
            $startIndex = ($currentPage - 1) * $itemsPerPage;
            $endIndex = min($startIndex + $itemsPerPage - 1, $totalClientes - 1);

            // Exibe apenas os chamados da página atual
            for ($i = $startIndex; $i <= $endIndex; $i++) {
                $row_cliente_pg = $clientes[$i]; 
                extract($row_cliente_pg);

                $html .= '<tr class="cliente-row" data-id="' . $pes_codigo . '">';
                $html .= '<td>' . $pes_codigo . '</td>';
                $html .= '<td>' . $pes_fantasia . '</td>';
                $html .= '<td>' . $pes_razao . '</td>';
                $html .= '<td>' . $pes_cpfcnpj . '</td>';
                $html .= '<td>' . $pes_datacadastro . '</td>';
                $html .= '<td>' . $pes_tipopessoa . '</td>';
                $html .= '<td>' . $pes_observacao . '</td>';
                $html .= '<td><button class="button-deletar" data-id="' . $pes_codigo . '">
                <i class="fa-regular fa-trash-can" style="color: #6768ab;"></i></button></td>';
                $html .= '</tr>';
            }
            $html .= '</tbody>';
            $html .= '</table>';
            $html .= '<div class="pagination">';

            // Botão de retrocesso
            if ($currentPage > 1) {
                $prevPage = $currentPage - 1;
                $html .= '<a href="?page=' . $prevPage . '" class="page-link"><span class="page-number">&lt;</span></a>';
            }
            
            for ($i = 1; $i <= $totalPages; $i++) {
                if ($i == $currentPage) {
                    // Página atual - destaque com círculo
                    $html .= '<span class="current-page-circle">' . $i . '</span>';
                } else {
                    // Página não atual - link normal
                    $html .= '<a href="?page=' . $i . '" class="page-link"><span class="page-number">' . $i . '</span></a>';
                }
            }
            
            // Botão de avanço
            if ($currentPage < $totalPages) {
                $nextPage = $currentPage + 1;
                $html .= '<a href="?page=' . $nextPage . '" class="page-link"><span class="page-number">&gt;</span></a>';
            }
            
            $html .= '<form action="" method="get" class="page-form">';
            $html .= '<input class="page-input" type="number" name="page" id="page" min="1" max="' . $totalPages . '" value="' . $currentPage . '" />';
            $html .= '</form>';
            
            $html .= '<script>';
            $html .= 'document.getElementById("page").addEventListener("input", function() {';
            $html .= '  var inputValue = this.value.trim();';
            $html .= '  if (inputValue !== "" && !isNaN(inputValue) && inputValue >= 1 && inputValue <= ' . $totalPages . ') {';
            $html .= '    window.location.href = "?page=" + inputValue;';
            $html .= '  }';
            $html .= '});';
            $html .= '</script>';

            $html .= '</div>';
            return $html;
        }
    }