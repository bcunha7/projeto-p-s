<script>
    $(document).ready(function() {
        $(".button-cadastrar").on("click", function() {
            window.location.href = "cadastrar_chamado.php";
        });
        $(".button-filtros").on("click", function() {
            $("#headerFilter").toggle("flex");
        });
    });
    document.addEventListener('DOMContentLoaded', function () {
    var table = document.querySelector('table');
    
    table.addEventListener('click', function (e) {
        var targetRow = e.target.closest('tr');
        
        if (targetRow) {
            // Remove a classe da linha anteriormente clicada
            var clickedRow = table.querySelector('.table-clicked-row');
            if (clickedRow) {
                clickedRow.classList.remove('table-clicked-row');
            }
            
            // Adiciona a classe à linha clicada
            targetRow.classList.add('table-clicked-row');
        }
    });

            $(".chamado-row").on("dblclick", function() {
                var chamadoId = $(this).data("id");
                window.location.href = "editar_chamado.php?cha_codigo=" + chamadoId;
            });

            $(".edit-link").on("click", function(e) {
                e.preventDefault();
                var chamadoId = $(this).closest(".chamado-row").data("id");
                window.location.href = "editar_chamado.php?cha_codigo=" + chamadoId;
            });
            $(".button-pesquisar").on("click", function() {
    
                // Remover campos vazios antes de enviar o formulário
                $("#filtroForm input, #filtroForm select").each(function() {
                    if ($(this).val() === '') {
                        $(this).prop('disabled', true);
                    }
                });

        // Enviar o formulário quando o botão de pesquisa for clicado
        $("#filtroForm").submit();
    });


            $("#filtrar-button").click(function() {
                // Remover campos vazios antes de enviar o formulário
                $("#filtroForm input, #filtroForm select").each(function() {
                    if ($(this).val() === '') {
                        $(this).prop('disabled', true);
                    }
                });

                $("#filtroForm").submit();
            });

            $("#limpar-filtros-button").click(function() {
                // Limpar valores dos campos do formulário
                $("input[name='pesquisar']").val('');
                $("select[name='pes_codigo']").val('');
                $("select[name='usu_codigo']").val('');
                $("select[name='cha_status']").val('');
                $("#cha_dataabertura").val('');

                // Remover classes de filtro da tabela
                $(".chamado-row").removeClass("table-clicked-row");

                // Atualizar a URL sem recarregar a página
                var newURL = window.location.protocol + "//" + window.location.host + window.location.pathname;
                history.replaceState({}, document.title, newURL);

                // Recarregar a página
                location.reload(true);
            });


            // Adiciona um ouvinte de evento de clique a todas as células do cabeçalho
            $('thead th').click(function () {
                // Obtemos o índice da coluna clicada
                var columnIndex = $(this).index();

                // Obtemos o tipo de ordenação da coluna (ascendente ou descendente)
                var sortOrder = $(this).data('sort-order') || 'asc';
                
                // Alterna a ordem de classificação para a próxima vez
                sortOrder = sortOrder === 'asc' ? 'desc' : 'asc';

                // Remove a classe 'asc' ou 'desc' de todas as colunas e adiciona à coluna clicada
                $('thead th').removeClass('asc desc');
                $(this).addClass(sortOrder);

                // Chama a função para reordenar a tabela
                ordenarTabela(columnIndex, sortOrder);
            });

    

        document.querySelectorAll(".button-deletar").forEach(function(btn) {
            btn.addEventListener("click", function() {
                var chamadoId = this.getAttribute("data-id");
                var confirmacao = confirm("Tem certeza que deseja excluir o chamado?");
                
                if (confirmacao) {
                    // Utiliza fetch para enviar uma solicitação POST para excluir_chamado.php
                    fetch("excluir_chamado.php", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded",
                        },
                        body: "id=" + chamadoId,
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.sucesso) {
                            // Recarrega a página ou atualiza a tabela dinamicamente
                            location.reload();
                        } else {
                            console.error("Erro ao excluir chamado:", data.mensagem);
                        }
                    })
                    .catch(error => console.error("Erro ao excluir chamado:", error));
                } else {
                    // Cancelou a exclusão, não faz nada
                }
            });
});

        });
    </script>