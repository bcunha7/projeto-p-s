    document.getElementById('applyFiltersButton').addEventListener('click', function() {
        var selectedMonth = document.getElementById('monthSelect').value;
        var selectedYear = document.getElementById('yearSelect').value;

        window.location.href = '?year=' + selectedYear + '&month=' + selectedMonth;
    });

    document.getElementById('selectAnoGraph').addEventListener('change', function() {
        var selectedYear2 = this.value;
        window.location.href = '?year2=' + selectedYear2;

    });
